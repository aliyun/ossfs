add_executable(test-fs test.cpp)
target_link_libraries(test-fs PRIVATE photon_shared)
add_test(NAME test-fs COMMAND $<TARGET_FILE:test-fs>)

add_executable(test-exportfs test_exportfs.cpp)
target_link_libraries(test-exportfs PRIVATE photon_shared)
add_test(NAME test-exportfs COMMAND $<TARGET_FILE:test-exportfs>)

add_executable(test-filecopy test_filecopy.cpp)
target_link_libraries(test-filecopy PRIVATE photon_shared)
add_test(NAME test-filecopy COMMAND $<TARGET_FILE:test-filecopy>)

add_executable(test-throttle-file test_throttledfile.cpp)
target_link_libraries(test-throttle-file PRIVATE photon_shared)
add_test(NAME test-throttle-file COMMAND $<TARGET_FILE:test-throttle-file>)

#add_executable(simplefuse simplefuse.cpp)
#target_link_libraries(simplefuse PRIVATE photon_shared ${FUSE3_LIBRARIES})
#target_compile_definitions(simplefuse PRIVATE _FILE_OFFSET_BITS=64 FUSE_USE_VERSION=35)