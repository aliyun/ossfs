/*
Copyright 2022 The Photon Authors

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "oss.h"

#include <netinet/in.h>
#include <strings.h>
#include <photon/common/alog-stdstring.h>
#include <photon/common/alog.h>
#include <photon/common/checksum/digest.h>
#include <photon/common/estring.h>
#include <photon/common/expirecontainer.h>
#include <photon/common/iovector.h>
#include <photon/ecosystem/simple_dom.h>
#include <photon/net/http/client.h>
#include <photon/net/http/url.h>
#include <photon/net/utils.h>
#include <time.h>
#include <unistd.h>

#include <algorithm>
#include <string>
#include <unordered_map>

namespace photon {
namespace objstore {

// unused constants will trigger compile error in photon,
// unless they are defined in a header file
#include "oss_constants.h"

using Verb = net::http::Verb;
using HTTP_STACK_OP =
    photon::net::http::Client::OperationOnStack<16 * 1024 - 1>;
using photon::net::http::verbstr;

#define make_ccl estring::make_conditional_cat_list
#define DEFINE_ONSTACK_OP(client, verb, url)          \
  int _CONCAT(__eno__, __LINE__) = 0;                 \
  DEFER(errno = _CONCAT(__eno__, __LINE__));          \
  HTTP_STACK_OP op(client, verb, (url));              \
  op.retry = 0;                                       \
  auto _CONCAT(_CONCAT(__defer__, __LINE__), __1__) = \
      make_defer([&]() __INLINE__ { _CONCAT(__eno__, __LINE__) = errno; });

static SimpleDOM::Node get_xml_node(HTTP_STACK_OP& op) {
  auto length = op.resp.headers.content_length();
  if (length > XML_LIMIT || length == 0)
    LOG_ERROR_RETURN(EINVAL, {}, "xml length invalid `", length);
  auto body_buf = (char*)malloc(length + 1);
  auto rc = op.resp.read(body_buf, length);
  body_buf[length] = '\0';
  if (rc != (ssize_t)length) {
    free(body_buf);
    LOG_ERROR_RETURN(0, {}, "body read error ` `", rc, length);
  }

  auto doc = SimpleDOM::parse(body_buf, length,
                              SimpleDOM::DOC_XML | SimpleDOM::DOC_OWN_TEXT);
  if (!doc) LOG_ERROR_RETURN(0, {}, "failed to parse resp_body");
  return doc;
}

// convert oss last modified time, e.g. "Fri, 04 Mar 2022 02:46:25 GMT"
static time_t get_lastmodified(std::string_view sv) {
  if (sv.size() != 29) {
    LOG_ERROR_RETURN(0, 0, "invalid lastmodified time: ", sv);
  }
  struct tm tm{};
  if (!strptime(sv.data(), "%a, %d %b %Y %H:%M:%S GMT", &tm)) {
    LOG_ERROR_RETURN(0, 0, "invalid lastmodified time: ", sv);
  }
  return timegm(&tm);  // GMT
}

// convert oss last modified time in listobjects, e.g.
// "2023-10-12T02:03:53.000Z"
static time_t get_list_lastmodified(std::string_view sv) {
  if (sv.size() != 24) {
    LOG_ERROR_RETURN(0, 0, "invalid lastmodified time: ", sv);
  }
  struct tm tm{};
  if (!strptime(sv.data(), "%Y-%m-%dT%H:%M:%S.000Z", &tm)) {
    LOG_ERROR_RETURN(0, 0, "invalid lastmodified time: ", sv);
  }
  return timegm(&tm);  // GMT
}

std::string_view lookup_mime_type(std::string_view name) {
  auto last_pos = name.find_last_of('.');
  if (last_pos != std::string_view::npos) name = name.substr(last_pos + 1);

  // extract the last extension
  const size_t MAX_EXT_LENGTH = 8;
  if (name.size() > MAX_EXT_LENGTH) name = name.substr(0, MAX_EXT_LENGTH);
  char ext[MAX_EXT_LENGTH + 1] = {};
  std::transform(name.begin(), name.end(), ext, ::tolower);
  return MIME_TYPE_MAP[ext];
}

class OssUrl {
 public:
  estring m_url, m_raw_object;
  rstring_view16 m_bucket, m_object;
  OssUrl() = default;
  OssUrl(std::string_view endpoint, std::string_view bucket,
         std::string_view object, bool is_http, bool path_style) {
    assert(!bucket.empty());
    init(endpoint, bucket, object, is_http, path_style);
  }
  void init(std::string_view endpoint, std::string_view bucket,
            std::string_view object, bool is_http, bool path_style) {
    bool has_slash = (object.size() > 0 && object[0] == '/');
    if (has_slash) object = object.substr(1);

    auto escaped_obj = photon::net::http::url_escape(object);
    auto scheme = photon::net::http::http_or_s(is_http);
    if (path_style) {
      m_url.appends(scheme, endpoint, "/", bucket, "/", escaped_obj);
      m_bucket = {scheme.size() + endpoint.size() + 1, bucket.size()};
      m_object = {m_bucket.offset() + bucket.size() + 1,
                  escaped_obj.size()};  // start without prefix /
    } else {
      m_url.appends(scheme, bucket, ".", endpoint, "/", escaped_obj);
      m_bucket = {scheme.size(), bucket.size()};
      m_object = {m_bucket.offset() + bucket.size() + endpoint.size() + 1 + 1,
                  escaped_obj.size()};  // start without prefix /
    }

    auto escaped = escaped_obj.size() > object.size();
    if (escaped) m_raw_object = object;
  }
  estring_view bucket() const { return m_url | m_bucket; }
  estring_view object(bool url_escaped = false) const {
    if (url_escaped || m_raw_object.empty()) {
      return m_url | m_object;
    }
    return m_raw_object;
  }

  estring_view append_params(const StringKV& params) {
    if (!params.empty()) {
      auto it = params.begin();
      m_url.appends("?", it->first,
                    make_ccl(!it->second.empty(), "=", it->second));
      while (++it != params.end()) {
        m_url.appends("&", it->first,
                      make_ccl(!it->second.empty(), "=", it->second));
      }
    }
    return m_url;
  }

  estring_view url() { return m_url; }
};

template <typename T>
struct NodeValue {
  explicit NodeValue(SimpleDOM::Node node) : node_(node) {}
  operator T() const { return convert_node_value(); }
  bool has_value() const { return node_; }

 private:
  T convert_node_value() const {
    return convert_impl(static_cast<T*>(nullptr));
  }
  estring_view convert_impl(estring_view*) const {
    return node_.to_string_view();
  }
  int64_t convert_impl(int64_t*) const { return node_.to_int64_t(); }
  SimpleDOM::Node node_;
};
using NodeStrValue = NodeValue<estring_view>;
using NodeInt64Value = NodeValue<int64_t>;

// Should be called only when status code is in error state.
// Normally with 4xx or 5xx.
static int error_http_status_to_errno(int status_code) {
  switch (status_code) {
    case 400:
      return EINVAL;
    case 401:
    case 403:
      return EACCES;
    case 404:
      return ENOENT;
    case 409:
      return ENOTSUP;
    case 416:
      return EINVAL;
  }
  return EIO;
}

// Extracts the last attempt's diagnostics into `trace`.
static void fill_request_trace(HTTP_STACK_OP& op, RequestTrace& trace,
                               bool throttled) {
  trace.http_code = op.status_code;
  trace.throttled = throttled || op.status_code == 429;
  auto& headers = op.resp.headers;
  auto it = headers.find(OSS_HEADER_KEY_X_OSS_REQUEST_ID);
  if (it != headers.end())
    trace.request_id.assign(it.second().data(), it.second().size());
  it = headers.find(OSS_HEADER_KEY_X_OSS_SERVER_TIME);
  if (it != headers.end())
    trace.server_time_ms = estring_view(it.second()).to_uint64();
  it = headers.find(OSS_HEADER_KEY_X_OSS_QOS_DELAY_TIME);
  if (it != headers.end())
    trace.qos_delay_ms = estring_view(it.second()).to_uint64();
  it = headers.find(OSS_HEADER_KEY_RETRY_AFTER);
  if (it != headers.end())
    trace.retry_after_ms = estring_view(it.second()).to_uint64() * 1000;
}

static int do_http_call(HTTP_STACK_OP& op, const ClientOptions& options,
                        std::string_view object,
                        RequestTrace* trace = nullptr) {
  int ret = -1;
  auto retry_times = options.retry_times;
  auto retry_interval = options.retry_base_interval_us;

  uint64_t qps_limit_retry_interval = 1000'000;
  auto qps_limit_total_retry_time =
      std::max(options.request_timeout_us, qps_limit_retry_interval);

  bool throttled = false;
  DEFER(if (trace) fill_request_trace(op, *trace, throttled));
  
__retry:
  if (trace) trace->attempts++;
  int __saved_errno = errno;
  {
    int r = 0;
    auto start_time = std::chrono::steady_clock::now();
    LOG_DEBUG("Sending oss request ` ` Range[`]", verbstr[op.req.verb()],
              op.req.target(), op.req.headers["Range"]);
    if (r == 0) {
      r = op.call();
      __saved_errno = errno;
    }
    auto latency = std::chrono::duration_cast<std::chrono::microseconds>(
                       std::chrono::steady_clock::now() - start_time)
                       .count();
    LOG_DEBUG(
        "Got oss response ` ` Range[`], code=` content_length=` latency_us=`",
        verbstr[op.req.verb()], op.req.target(), op.req.headers["Range"],
        op.resp.status_code(), op.resp.headers.content_length(), latency);
    if (r < 0) {
      if (retry_times-- > 0) {
        photon::thread_usleep(retry_interval);
        retry_interval *= 2;
        LOG_ERROR("Retrying oss request ` `", verbstr[op.req.verb()],
                  op.req.target());
        goto __retry;
      }
    }
  }

  if (op.status_code != 200 && op.status_code != 206 && op.status_code != 204) {
    if (op.status_code != -1 && op.status_code != 404) {
      auto reader = get_xml_node(op);
      auto error_res = reader["Error"];
      std::string_view code_view = error_res["Code"].to_string_view();
      // clang-format off
      LOG_ERROR(
          "Operation on [`] failed! RequestId[`], OSSError: Code[`], Message[`], EC[`]",
          object, op.resp.headers["x-oss-request-id"], code_view,
          error_res["Message"].to_string_view(),
          error_res["EC"].to_string_view());
      // clang-format on

      if (code_view.find("QpsLimitExceeded") != std::string::npos) {
        throttled = true;
        if (qps_limit_retry_interval > 0) {
          photon::thread_usleep(qps_limit_retry_interval);
          qps_limit_total_retry_time -= qps_limit_retry_interval;
          qps_limit_retry_interval = std::min(qps_limit_retry_interval * 2,
                                              qps_limit_total_retry_time);
          LOG_ERROR("Retrying oss request ` `, ` us more to retry",
                    verbstr[op.req.verb()], op.req.target(),
                    qps_limit_total_retry_time);
          goto __retry;
        }
        retry_times = 0;  // no more tryings in qps limit case
      }
    }

    if (op.status_code / 100 == 5) {
      if (retry_times-- > 0) {
        photon::thread_usleep(retry_interval);
        retry_interval *= 2;
        LOG_ERROR("Retrying oss request ` `", verbstr[op.req.verb()],
                  op.req.target());
        goto __retry;
      }
    }
    if (op.status_code == -1) {
        LOG_ERROR("operation on [`] failed!, http connection error `", 
                  object, ERRNO(__saved_errno));
        errno = __saved_errno;
        if (errno != ETIMEDOUT) errno = EIO;
        return ret;
    }
    if (op.status_code / 100 == 4) {
      errno = error_http_status_to_errno(op.status_code);
    }
    return ret;
  }
  return 0;
}

static int verify_crc64_if_needed(HTTP_STACK_OP& op, std::string_view object,
                                  const uint64_t* expected_crc64) {
  if (!expected_crc64) return 0;
  auto it = op.resp.headers.find("x-oss-hash-crc64ecma");
  if (it == op.resp.headers.end()) {
    LOG_WARN("crc64 not found in object ", object);
    return 0;
  }
  uint64_t crc64;
  if (!estring_view(it.second()).to_uint64_check(&crc64) ||
      *expected_crc64 != crc64) {
    LOG_ERROR_RETURN(EIO, -1,
                     "crc64 mismatch of object: `, expected: `, actual: `",
                     object, *expected_crc64, it.second());
  }
  return 0;
}

static bool get_resp_crc64(HTTP_STACK_OP& op, uint64_t* crc64) {
  auto it = op.resp.headers.find("x-oss-hash-crc64ecma");
  if (it == op.resp.headers.end()) return false;
  return estring_view(it.second()).to_uint64_check(crc64);
}

static ssize_t body_writer_cb(void* iov_view, photon::net::http::Request* req) {
  auto view = static_cast<iovector_view*>(iov_view);
  auto ret = req->writev(view->iov, view->iovcnt);
  if (ret != static_cast<ssize_t>(view->sum())) {
    LOG_ERROR_RETURN(0, -1, "stream writev failed!", VALUE(ret), VALUE(errno));
  }
  return 0;
}

static std::string md5_base64(iovector_view view) {
  std::string ret;
  unsigned char hash[MD5_DIGEST_LENGTH];
  md5 md5sum;
  for (const auto& iov : view) {
    md5sum.update(iov.iov_base, iov.iov_len);
  }
  md5sum.finalize(hash);
  photon::net::Base64Encode({(char*)hash, MD5_DIGEST_LENGTH}, ret);
  return ret;
}

class OssClientImpl : public Client {
 public:
  OssClientImpl(const ClientOptions& options, Authenticator* authenticator);
  ~OssClientImpl();

  int put_bucket(std::string_view agent_bucket);

  int delete_bucket();

  int list_objects(std::string_view prefix, ListObjectsCallback cb,
                   ListObjectsParameters = {}, std::string* marker = nullptr,
                   RequestTrace* trace = nullptr);

  int head_object(std::string_view object, ObjectHeaderMeta& meta,
                  RequestTrace* trace = nullptr);

  int fill_meta(HTTP_STACK_OP& op, ObjectMeta& meta);
  int fill_meta(HTTP_STACK_OP& op, ObjectHeaderMeta& meta);
  int fill_upload_response(HTTP_STACK_OP& op, ObjectUploadOptions& opts);

  ssize_t get_object_range(std::string_view object, off_t offset,
                           size_t cnt, BodyReader reader,
                           ObjectHeaderMeta* meta = nullptr,
                           RequestTrace* trace = nullptr);

  int batch_get_objects(std::vector<GetObjectParameters>& params,
                        RequestTrace* trace = nullptr);

  int get_object_ranges(std::string_view object,
                        std::vector<GetRangeParameters>& ranges,
                        RequestTrace* trace = nullptr);

  ssize_t put_object(std::string_view object, size_t cnt,
                     BodyWriter writer, ObjectUploadOptions& opts,
                     RequestTrace* trace = nullptr);

  ssize_t append_object(std::string_view object, const struct iovec* iov,
                        int iovcnt, off_t position, ObjectUploadOptions& opts,
                        RequestTrace* trace = nullptr);

  int copy_object(std::string_view src_object, std::string_view dst_object,
                  ObjectCopyOptions& opts);

  int init_multipart_upload(std::string_view object, void** context);

  ssize_t upload_part(void* context, size_t cnt,
                      int part_number, BodyWriter writer,
                      ObjectUploadOptions& opts);

  int upload_part_copy(void* context, off_t offset, size_t count,
                       int part_number, std::string_view from,
                       ObjectPartCopyOptions& opts);

  int complete_multipart_upload(void* context, ObjectUploadOptions& opts);

  int abort_multipart_upload(void* context);

  int delete_objects(const std::vector<std::string_view>& objects,
                     std::string_view prefix = {});

  int delete_object(std::string_view obj);

  int rename_object(std::string_view src_path, std::string_view dst_path,
                    bool set_mime = false);

  int put_symlink(std::string_view obj, std::string_view target);

  int get_symlink(std::string_view obj, std::string& target);

  int get_object_meta(std::string_view obj, ObjectMeta& meta);

  void set_credentials(CredentialParameters&& credentials);

 private:
  OssUrl make_oss_url(std::string_view object) {
    return make_oss_url(object, m_bucket);
  }
  OssUrl make_oss_url(std::string_view object, std::string_view bucket) {
    return {m_endpoint, bucket, object, m_is_http, m_oss_options.path_style};
  }
  int append_auth_headers(photon::net::http::Verb v, const OssUrl& oss_url,
                          photon::net::http::Headers& headers,
                          const StringKV& query_params = {},
                          bool invalidate_cache = false);
  void inject_custom_headers(photon::net::http::Headers& headers);
  int sign_and_call(HTTP_STACK_OP& op, photon::net::http::Verb verb,
                    const OssUrl& oss_url, const StringKV& query_params = {},
                    bool invalidate_cache = false,
                    RequestTrace* trace = nullptr);

  int walk_list_results(const SimpleDOM::Node& node, ListObjectsCallback cb);
  int do_list_objects_v2(std::string_view bucket, std::string_view prefix,
                         ListObjectsCallback cb, bool delimiters, int maxKeys,
                         std::string* marker, std::string_view start_after,
                         RequestTrace* trace = nullptr);
  int do_list_objects_v1(std::string_view bucket, std::string_view prefix,
                         ListObjectsCallback cb, bool delimiters, int maxKeys,
                         std::string* marker,
                         RequestTrace* trace = nullptr);

  int do_copy_object(OssUrl& src_oss_url, OssUrl& dst_oss_url,
                     ObjectCopyOptions& opts);
  int do_delete_object(OssUrl& oss_url);

  int read_range_parts(HTTP_STACK_OP& op, std::string_view object,
                       std::vector<GetRangeParameters>& ranges);

  int do_delete_objects(estring_view bucket, estring_view prefix,
                        const std::vector<std::string_view>& objects,
                        size_t start, size_t count);

  std::string m_endpoint, m_bucket;
  bool m_is_http = false;

  ClientOptions m_oss_options;
  photon::net::http::Client* m_client = nullptr;
  Authenticator* m_authenticator = nullptr;
};

#define OssClient OssClientImpl

// Resolve filters enforcing ClientOptions::ip_version. The leading void* is
// the Delegate object slot, bound to nullptr.
static bool oss_resolve_filter_ipv4(void*, photon::net::IPAddr addr) {
  return addr.is_ipv4();
}
static bool oss_resolve_filter_ipv6(void*, photon::net::IPAddr addr) {
  return addr.is_ipv6();
}

// Resolver decorator enforcing a single address family: wraps a private
// DefaultResolver, keeping only addresses that pass `filter`. Each OSS client
// owns one, so its DNS cache is private and the filter is never bypassed.
class FilteredResolver : public photon::net::Resolver {
 public:
  std::unique_ptr<photon::net::Resolver> inner{photon::net::new_default_resolver()};
  Delegate<bool, photon::net::IPAddr> filter;

  explicit FilteredResolver(Delegate<bool, photon::net::IPAddr> filter) : filter(filter) {}

  photon::net::IPAddr resolve(std::string_view host) override {
    return inner->resolve_filter(host, filter);
  }
  // The HTTP client only calls resolve(); enforce the same filter here.
  photon::net::IPAddr resolve_filter(std::string_view host, Delegate<bool, photon::net::IPAddr>) override {
    return inner->resolve_filter(host, filter);
  }
  void discard_cache(std::string_view host, photon::net::IPAddr ip) override {
    inner->discard_cache(host, ip);
  }
};

OssClient::OssClient(const ClientOptions& options, Authenticator* authenticator)
    : m_bucket(options.bucket),
      m_oss_options(options),
      m_authenticator(authenticator) {
  estring_view esv(options.endpoint);
  if (esv.starts_with("https://")) {
    m_endpoint = options.endpoint.substr(8);
    m_is_http = false;
  } else if (esv.starts_with("http://")) {
    m_endpoint = options.endpoint.substr(7);
    m_is_http = true;
  } else {
    m_endpoint = options.endpoint;
  }

  m_client = photon::net::http::new_http_client();
  m_client->timeout(m_oss_options.request_timeout_us);
  m_client->set_connection_idle_expiration(m_oss_options.connection_idle_expiration_us);
  m_client->set_user_agent(m_oss_options.user_agent);
  if (!m_oss_options.proxy.empty()) m_client->set_proxy(m_oss_options.proxy);

  // For a single-family ip_version, give the client a private resolver that only
  // accepts matching addresses, so the filter is never bypassed by a shared cache.
  switch (m_oss_options.ip_version) {
    case IPVersion::kIPv4Only:
    case IPVersion::kIPv6Only: {
      auto filter = m_oss_options.ip_version == IPVersion::kIPv4Only
                        ? Delegate<bool, photon::net::IPAddr>{nullptr, &oss_resolve_filter_ipv4}
                        : Delegate<bool, photon::net::IPAddr>{nullptr, &oss_resolve_filter_ipv6};
      m_client->set_resolver(new FilteredResolver(filter), true);
      break;
    }
    case IPVersion::kBoth:
    default:
      break;
  }

  auto& ch = m_oss_options.custom_headers;
  for (auto it = ch.begin(); it != ch.end();) {
    std::transform(it->first.begin(), it->first.end(), it->first.begin(), ::tolower);
    // reserved for authenticator;
    if (it->first == "authorization" || it->first == "date")
      it = ch.erase(it);
    else
      ++it;
  }

  if (!options.bind_ips.empty()) {
    std::vector<photon::net::IPAddr> ip_vec;
    auto ips = estring_view(options.bind_ips).split(',');
    for (const auto& ip : ips) {
      photon::net::IPAddr addr(ip.to_string().c_str());
      if (!addr.undefined()) {
        ip_vec.push_back(addr);
      } else {
        LOG_WARN("invalid bind ip: `", ip);
      }
    }

    if (!ip_vec.empty()) {
      m_client->set_bind_ips(ip_vec);
      LOG_INFO("Use customized bind_ips: `", options.bind_ips);
    } else {
      LOG_ERROR("Invalid bind_ips: `, fallback to default mode",
                options.bind_ips);
    }
  }
}

OssClient::~OssClient() {
  delete m_client;
  delete m_authenticator;
}

#undef OssClient
#define OssClient inline OssClientImpl

int OssClient::append_auth_headers(photon::net::http::Verb v, const OssUrl& oss_url,
                                   photon::net::http::Headers& headers,
                                   const StringKV& query_params,
                                   bool invalidate_cache) {
  Authenticator::SignParameters params;
  params.verb = v;
  params.query_params = query_params;
  params.region = m_oss_options.region;
  params.endpoint = m_oss_options.endpoint;
  params.bucket = m_oss_options.bucket;
  params.object = oss_url.object();
  params.invalidate_cache = invalidate_cache;

  // inject custom headers before sign so x-oss-* headers participate in signing
  inject_custom_headers(headers);
  return m_authenticator->sign(headers, params);
}

void OssClient::inject_custom_headers(photon::net::http::Headers& headers) {
  for (const auto& kv : m_oss_options.custom_headers) {
    headers.insert(kv.first, kv.second);
  }
}

int OssClient::sign_and_call(HTTP_STACK_OP& op, photon::net::http::Verb verb,
                             const OssUrl& oss_url,
                             const StringKV& query_params,
                             bool invalidate_cache, RequestTrace* trace) {
  int r = append_auth_headers(verb, oss_url, op.req.headers, query_params,
                              invalidate_cache);
  if (r < 0) return r;
  return do_http_call(op, m_oss_options, oss_url.object(), trace);
}

int OssClient::walk_list_results(const SimpleDOM::Node& list_bucket_result,
                                 ListObjectsCallback cb) {
  for (auto child : list_bucket_result.enumerable_children("Contents")) {
    auto key = NodeStrValue(child["Key"]);
    auto size = NodeInt64Value(child["Size"]);
    auto mtime = NodeStrValue(child["LastModified"]);
    auto etag = NodeStrValue(child["ETag"]);
    auto type = NodeStrValue(child["Type"]);

    if (!key.has_value() || !size.has_value() || !mtime.has_value() ||
        !etag.has_value())
      LOG_ERROR_RETURN(EINVAL, -1,
                       "unexpected response: missing required fields");

    auto mtim = get_list_lastmodified(mtime);
    auto r = cb({key, etag, type, static_cast<size_t>(size), mtim,
                 false /*not comm prefix*/});
    if (r < 0) return r;
  }
  for (auto child : list_bucket_result.enumerable_children("CommonPrefixes")) {
    auto key = NodeStrValue(child["Prefix"]);
    if (!key.has_value())
      LOG_ERROR_RETURN(EINVAL, -1,
                       "unexpected response: missing required fields");
    auto r = cb({key, {}, {}, 0, 0, true /*comm prefix*/});
    if (r < 0) return r;
  }
  return 0;
}

int OssClient::do_list_objects_v2(std::string_view bucket, std::string_view prefix,
                                  ListObjectsCallback cb, bool delimiters, int maxKeys,
                                  std::string* marker, std::string_view start_after,
                                  RequestTrace* trace) {
  if (maxKeys > 1000 || maxKeys <= 0) maxKeys = m_oss_options.max_list_ret_cnt;
  estring_view _mark;
  if (marker) _mark = *marker;

  estring escaped_prefix = photon::net::http::url_escape(prefix);
  estring escaped_delimiter = photon::net::http::url_escape("/");
  estring escaped_marker = photon::net::http::url_escape(_mark);
  estring escaped_start_after = photon::net::http::url_escape(start_after);
  estring max_key_str = std::to_string(maxKeys);
  // must appear in dictionary order!
  DEFINE_APPENDABLE_ORDERED_STRING_KV(
      query_params, 2,
      {
          {OSS_PARAM_KEY_LIST_TYPE, "2"},
          {OSS_PARAM_KEY_MAX_KEYS, max_key_str},
          {OSS_PARAM_KEY_PREFIX, escaped_prefix},
      });

  if (delimiters)
    query_params.insert({OSS_PARAM_KEY_DELIMITER, escaped_delimiter});
  if (!_mark.empty())
    query_params.insert({OSS_PARAM_KEY_CONTINUATION_TOKEN, escaped_marker});
  if (!start_after.empty())
    query_params.insert({OSS_PARAM_KEY_START_AFTER, escaped_start_after});
  auto oss_url = make_oss_url({}, bucket);
  DEFINE_ONSTACK_OP(m_client, Verb::GET, oss_url.append_params(query_params));
  int r = sign_and_call(op, Verb::GET, oss_url, query_params, false, trace);
  if (r < 0) return r;

  auto reader = get_xml_node(op);
  if (!reader) LOG_ERROR_RETURN(0, -1, "failed to parse xml resp_body");
  auto list_bucket_result = reader["ListBucketResult"];
  if (!list_bucket_result) LOG_ERROR_RETURN(EINVAL, -1, "unexpected empty response");
  r = walk_list_results(list_bucket_result, cb);
  if (r < 0) return r;
  if (marker) {
    auto next_marker = list_bucket_result["NextContinuationToken"];
    *marker = next_marker ? next_marker.to_string_view() : "";
  }
  return 0;
}

int OssClient::do_list_objects_v1(std::string_view bucket,
                                  std::string_view prefix,
                                  ListObjectsCallback cb, bool delimiters,
                                  int maxKeys, std::string* marker,
                                  RequestTrace* trace) {
  if (maxKeys > 1000 || maxKeys <= 0) maxKeys = m_oss_options.max_list_ret_cnt;
  estring_view _mark;
  if (marker) _mark = *marker;

  estring escaped_prefix = photon::net::http::url_escape(prefix);
  estring escaped_delimiter = photon::net::http::url_escape("/");
  estring escaped_marker = photon::net::http::url_escape(_mark);
  estring max_key_str = std::to_string(maxKeys);
  // must appear in dictionary order!
  DEFINE_APPENDABLE_ORDERED_STRING_KV(
      query_params, 2,
      {
          {OSS_PARAM_KEY_MAX_KEYS, max_key_str},
          {OSS_PARAM_KEY_PREFIX, escaped_prefix},
      });
  if (delimiters)
    query_params.insert({OSS_PARAM_KEY_DELIMITER, escaped_delimiter});
  if (!_mark.empty())
    query_params.insert({OSS_PARAM_KEY_MARKER, escaped_marker});

  auto oss_url = make_oss_url({}, bucket);
  DEFINE_ONSTACK_OP(m_client, Verb::GET, oss_url.append_params(query_params));
  int r = sign_and_call(op, Verb::GET, oss_url, query_params, false, trace);
  if (r < 0) return r;

  auto reader = get_xml_node(op);
  if (!reader) LOG_ERROR_RETURN(0, -1, "failed to parse xml resp_body");
  auto list_bucket_result = reader["ListBucketResult"];
  if (!list_bucket_result) LOG_ERROR_RETURN(EINVAL, -1, "unexpected empty response");
  r = walk_list_results(list_bucket_result, cb);
  if (r < 0) return r;
  if (marker) {
    auto next_marker = list_bucket_result["NextMarker"];
    *marker = next_marker ? next_marker.to_string_view() : "";
  }
  return 0;
}

int OssClient::do_copy_object(OssUrl& src_oss_url, OssUrl& dst_oss_url,
                              ObjectCopyOptions& opts) {
  DEFINE_ONSTACK_OP(m_client, Verb::PUT, dst_oss_url.url());

  estring oss_copy_source =
      estring("/").appends(src_oss_url.bucket(), "/", src_oss_url.object(true));
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_COPY_SOURCE, oss_copy_source);
  if (!opts.overwrite) {
    op.req.headers.insert(OSS_HEADER_KEY_X_OSS_FORBID_OVERWRITE, "true");
  }

  std::string_view dst_type{};  // use the same content type as the source
  if (opts.set_mime) {
    auto src_type = lookup_mime_type(src_oss_url.object());
    auto new_dst_type = lookup_mime_type(dst_oss_url.object());
    if (src_type != new_dst_type) dst_type = new_dst_type;
    if (!dst_type.empty()) {
      op.req.headers.insert(OSS_HEADER_KEY_X_OSS_METADATA_DIRECTIVE, "REPLACE");
      op.req.headers.insert(OSS_HEADER_KEY_CONTENT_TYPE, dst_type);
    }
  }

  opts.crc64.reset();
  int r = sign_and_call(op, Verb::PUT, dst_oss_url);
  if (r < 0) return r;

  uint64_t crc64;
  if (get_resp_crc64(op, &crc64)) opts.crc64.set(crc64);
  return 0;
}

int OssClient::do_delete_object(OssUrl& oss_url) {
  DEFINE_ONSTACK_OP(m_client, Verb::DELETE, oss_url.url());
  return sign_and_call(op, Verb::DELETE, oss_url);
}

static std::string xml_escape(std::string_view object) {
  static const std::unordered_map<char, std::string> xml_escape_map = {
      {'&', "&amp;"},
      {'<', "&lt;"},
      {'>', "&gt;"},
      {'"', "&quot;"},
      {'\'', "&apos;"},
      // refer to go sdk to handle belowing charactors in deleting multiple
      // objects
      {'\t', "&#x9;"},
      {'\n', "&#xA;"},
      {'\r', "&#xD;"},
  };

  std::string escaped_object;
  escaped_object.reserve(object.size() * 2);
  for (auto c : object) {
    auto it = xml_escape_map.find(c);
    if (it != xml_escape_map.end())
      escaped_object += it->second;
    else
      escaped_object += c;
  }
  return escaped_object;
}

int OssClient::do_delete_objects(estring_view bucket, estring_view prefix,
                                 const std::vector<std::string_view>& objects,
                                 size_t start, size_t to_delete_size) {
  std::string_view req_head = "<Delete><Quiet>false</Quiet>";
  std::string_view req_tail = "</Delete>";
  estring req_list;
  for (size_t i = start; i < start + to_delete_size; ++i) {
    req_list.appends("<Object><Key>", xml_escape(prefix),
                     xml_escape(objects[i]), "</Key></Object>");
  }

  int retry_times = m_oss_options.retry_times;
  auto retry_interval = m_oss_options.retry_base_interval_us;

  struct iovec iov[3] = {{(void*)req_head.data(), req_head.size()},
                         {(void*)req_list.data(), req_list.size()},
                         {(void*)req_tail.data(), req_tail.size()}};
  iovector_view body_view(iov, 3);
  auto oss_url = make_oss_url("/", bucket);
  auto md5 = md5_base64(body_view);

  DEFINE_CONST_STATIC_ORDERED_STRING_KV(query_params,
                                        {// must appear in dictionary order!
                                         {OSS_PARAM_KEY_DELETE, ""}});

  DEFINE_ONSTACK_OP(m_client, Verb::POST, oss_url.append_params(query_params));
  op.req.headers.insert(OSS_HEADER_KEY_CONTENT_MD5, md5);
  op.req.headers.content_length(body_view.sum());
  op.body_writer = {&body_view, &body_writer_cb};
  int r =
      append_auth_headers(Verb::POST, oss_url, op.req.headers, query_params);
  if (r < 0) return r;

retry:
  size_t deleted_size = 0;
  r = do_http_call(op, m_oss_options, oss_url.object());
  if (r < 0) return r;

  auto reader = get_xml_node(op);
  auto result = reader["DeleteResult"];
  for (auto child : result.enumerable_children("Deleted")) {
    auto key = child["Key"];
    if (key) deleted_size++;
  }

  if (deleted_size != to_delete_size) {
    // Partial deletion happens when OSS server side is with pressure.
    // If this is the case , we just have another try. It's OK if some keys
    // have been deleted by the server in last round as OSS will treat it as
    // successful when deleting one non-existed key. And the returned deleted
    // result will contain the non-existed key.
    if (retry_times-- > 0) {
      LOG_WARN("Partial deletion. To delete ` deleted `. Retrying...",
               to_delete_size, deleted_size);
      photon::thread_usleep(retry_interval);
      goto retry;
    }
    LOG_ERROR_RETURN(EIO, -1, "Partial deletion");
  }
  return 0;
}

int OssClient::rename_object(std::string_view src_path,
                             std::string_view dst_path, bool set_mime) {
  auto src_oss_url = make_oss_url(src_path);
  auto dst_oss_url = make_oss_url(dst_path);

  ObjectCopyOptions opts;
  opts.overwrite = true;
  opts.set_mime = set_mime;
  if (do_copy_object(src_oss_url, dst_oss_url, opts) < 0) return -1;
  return do_delete_object(src_oss_url);
}

int OssClient::put_symlink(std::string_view obj, std::string_view target) {
  DEFINE_CONST_STATIC_ORDERED_STRING_KV(query_params,
                                        {
                                            {OSS_PARAM_KEY_SYMLINK, ""},
                                        });
  auto oss_url = make_oss_url(obj);
  DEFINE_ONSTACK_OP(m_client, Verb::PUT, oss_url.append_params(query_params));
  auto escaped_tgt = photon::net::http::url_escape(target);
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_SYMLINK_TARGET, escaped_tgt);
  return sign_and_call(op, Verb::PUT, oss_url, query_params);
}

int OssClient::get_symlink(std::string_view obj, std::string& target) {
  DEFINE_CONST_STATIC_ORDERED_STRING_KV(query_params,
                                        {
                                            {OSS_PARAM_KEY_SYMLINK, ""},
                                        });
  auto oss_url = make_oss_url(obj);
  DEFINE_ONSTACK_OP(m_client, Verb::GET, oss_url.append_params(query_params));
  int r = sign_and_call(op, Verb::GET, oss_url, query_params);
  if (r < 0) return r;
  target = photon::net::http::url_unescape(
      op.resp.headers[OSS_HEADER_KEY_X_OSS_SYMLINK_TARGET]);
  return r;
}

int OssClient::put_bucket(std::string_view agent_bucket) {
  auto oss_url = make_oss_url({});
  DEFINE_ONSTACK_OP(m_client, Verb::PUT, oss_url.url());
  if (!agent_bucket.empty())
    op.req.headers.insert(OSS_HEADER_KEY_X_OSS_AGENTIC_BUCKET, agent_bucket);
  return sign_and_call(op, Verb::PUT, oss_url);
}

int OssClient::delete_bucket() {
  auto oss_url = make_oss_url({});
  DEFINE_ONSTACK_OP(m_client, Verb::DELETE, oss_url.url());
  return sign_and_call(op, Verb::DELETE, oss_url);
}

int OssClient::delete_objects(const std::vector<std::string_view>& objects,
                              std::string_view obj_prefix) {
  size_t start = 0;
  // 1000 is the largest allowed batch size.
  while (start < objects.size()) {
    size_t cnt = std::min(objects.size() - start, (size_t)1000);
    int r = do_delete_objects(m_bucket, obj_prefix, objects, start, cnt);
    if (r < 0) return r;
    start += cnt;
  }
  return 0;
}

int OssClient::list_objects(std::string_view prefix, ListObjectsCallback cb,
                            ListObjectsParameters params, std::string* nct,
                            RequestTrace* trace) {
  std::string marker;
  int max_keys = params.max_keys;
  if (nct) marker = *nct;
  if (max_keys == 0) max_keys = m_oss_options.max_list_ret_cnt;

  int r = 0;
  do {
    if (params.ver == 2) {
      r = do_list_objects_v2(m_bucket, prefix, cb, params.slash_delimiter,
                             max_keys, &marker, params.start_after, trace);
    } else {
      r = do_list_objects_v1(m_bucket, prefix, cb, params.slash_delimiter,
                             max_keys, &marker, trace);
    }
    if (r < 0) return r;
  } while (!nct && !marker.empty());
  if (nct) *nct = marker;
  return 0;
}

int OssClient::head_object(std::string_view object, ObjectHeaderMeta& meta,
                           RequestTrace* trace) {
  auto oss_url = make_oss_url(object);
  DEFINE_ONSTACK_OP(m_client, Verb::HEAD, oss_url.url());
  int r = sign_and_call(op, Verb::HEAD, oss_url, {}, false, trace);
  if (r < 0) return r;
  return fill_meta(op, meta);
}

int OssClient::fill_meta(HTTP_STACK_OP& op, ObjectHeaderMeta& meta) {
  int ret = fill_meta(op, (ObjectMeta&)meta);
  if (ret < 0) return ret;

  auto it = op.resp.headers.find("x-oss-storage-class");
  if (it != op.resp.headers.end()) {
    meta.set_storage_class();
    meta.storage_class.assign(it.second().data(), it.second().size());
  }

  it = op.resp.headers.find("x-oss-hash-crc64ecma");
  if (it != op.resp.headers.end()) {
    meta.set_crc64(estring_view(it.second()).to_uint64());
  }
  return 0;
}

int OssClient::fill_meta(HTTP_STACK_OP& op, ObjectMeta& meta) {
  auto len = op.resp.resource_size();
  if (len == -1) LOG_ERROR_RETURN(0, -1, "Unexpected http response header");

  meta.set_size(len);
  auto it = op.resp.headers.find("Last-Modified");
  if (it != op.resp.headers.end()) {
    if (it.second().empty())
      meta.set_mtime(0);
    else
      meta.set_mtime(get_lastmodified(it.second()));
  }

  it = op.resp.headers.find("ETag");
  if (it != op.resp.headers.end()) {
    meta.set_etag();
    meta.etag.assign(it.second().data(), it.second().size());
  }

  it = op.resp.headers.find("x-oss-object-type");
  if (it != op.resp.headers.end()) {
    meta.set_type();
    meta.type.assign(it.second().data(), it.second().size());
  }
  return 0;
}

int OssClient::fill_upload_response(HTTP_STACK_OP& op,
                                    ObjectUploadOptions& opts) {
  if (opts.etag) {
    auto it = op.resp.headers.find("ETag");
    if (it != op.resp.headers.end()) {
      opts.etag->assign(it.second().data(), it.second().size());
    }
  }
  return 0;
}

ssize_t OssClient::get_object_range(std::string_view obj_path, off_t offset,
                                    size_t cnt, BodyReader reader,
                                    ObjectHeaderMeta* meta,
                                    RequestTrace* trace) {
  if (cnt == 0) return 0;
  int retry_times = m_oss_options.retry_times;
  auto retry_interval = m_oss_options.retry_base_interval_us;

  bool invalidate_cache = false;
retry:
  auto oss_url = make_oss_url(obj_path);
  DEFINE_ONSTACK_OP(m_client, Verb::GET, oss_url.url());
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_RANGE_BEHAVIOR, "standard");
  op.req.headers.range(offset, offset + cnt - 1);
  int r = sign_and_call(op, Verb::GET, oss_url, {}, invalidate_cache, trace);
  if (r < 0) {
    if (errno == EACCES && !invalidate_cache) {
      invalidate_cache = true;
      errno = 0;
      goto retry;
    }
    return r;
  }

  uint64_t content_length = op.resp.headers.content_length();
  auto ret = reader(&op.resp);
  // we have encountered partial read issue because of the socket was
  // unexpectedly closed
  if (ret != static_cast<ssize_t>(content_length)) {
    LOG_ERROR("Get object ` return partial data, offset `, expected: `, got: `",
              obj_path, offset, cnt, ret);
    if (retry_times-- > 0) {
      photon::thread_usleep(retry_interval);
      retry_interval *= 2;
      LOG_ERROR("Retrying oss request ` `", verbstr[op.req.verb()],
                op.req.target());
      // op.reset(nullptr);
      goto retry;
    }
    ret = -1;
    errno = EIO;
  } else {
    if (meta) fill_meta(op, *meta);
  }

  return ret;
}

// "multipart/byteranges;boundary=<boundary>"
static estring_view get_byteranges_boundary(std::string_view content_type) {
  estring_view ct(content_type);
  if (!ct.istarts_with("multipart/byteranges")) return {};
  auto pos = ct.find("boundary=");
  if (pos == estring_view::npos) return {};
  auto boundary = ct.substr(pos + 9);
  auto semicolon = boundary.find(';');
  if (semicolon != estring_view::npos) boundary = boundary.substr(0, semicolon);
  return boundary.trim(charset(" \""));
}

// The body of a multi-range GET, i.e. multipart/byteranges (RFC 9110 14.6):
// "--<boundary>\r\n<part headers>\r\n\r\n<payload>\r\n" per part, closed by
// "--<boundary>--". Parsing is deliberately not general: get_object_ranges()
// already knows which ranges it asked for, so parts are verified against them
// instead of being dispatched by their content-range.
class ByterangesStream {
 public:
  using Response = photon::net::http::Response;

  ByterangesStream(Response* response, std::string_view boundary)
      : response_(response) {
    delimiter_.appends("--", boundary);
  }

  // Reads the next part header block, reporting the range it carries as
  // [start, end] together with the object size.
  int next_part(uint64_t& start, uint64_t& end) {
    estring_view block;
    for (size_t pos; true;) {
      estring_view buffered(buf_ + head_, tail_ - head_);
      if ((pos = buffered.find("\r\n\r\n")) != estring_view::npos) {
        block = buffered.substr(0, pos);
        head_ += pos + 4;
        break;
      }
      if (fill() < 0) return -1;
    }
    if (!block.starts_with(delimiter_))
      LOG_ERROR_RETURN(EIO, -1, "part not delimited by [`]: [`]", delimiter_,
                       block);

    for (auto line : block.split_lines()) {
      // "Content-range: bytes <start>-<end>/<object size>"
      if (line.size() < 14 || strncasecmp(line.data(), "content-range:", 14))
        continue;
      auto v = line.substr(14).trim();
      auto space = v.find(' '), dash = v.find('-'), slash = v.find('/');
      if (!v.istarts_with("bytes") || slash == estring_view::npos ||
          space > dash || dash > slash)
        LOG_ERROR_RETURN(EIO, -1, "malformed content-range [`]", line);
      start = v.substr(space + 1, dash - space - 1).to_uint64();
      end = v.substr(dash + 1, slash - dash - 1).to_uint64();
      return 0;
    }
    LOG_ERROR_RETURN(EIO, -1, "part without content-range: [`]", block);
  }

  // Scatters the current part's payload into iov, and consumes the CRLF that
  // terminates it. return size, or -1 if the body is short.
  ssize_t read_payload(const struct iovec* iov, int iovcnt, size_t size) {
    SmartCloneIOV<32> ciov(iov, iovcnt);
    iovector_view view(ciov.ptr, iovcnt);
    auto read_ahead = std::min(size, tail_ - head_);
    if (read_ahead > 0) {
      view.extract_front(view.memcpy_from(buf_ + head_, read_ahead));
      head_ += read_ahead;
    }
    while (!view.empty()) {
      auto ret = response_->readv(view.iov, view.iovcnt);
      if (ret <= 0) LOG_ERROR_RETURN(EIO, -1, "part payload truncated");
      view.extract_front(ret);
    }
    return expect("\r\n") < 0 ? -1 : (ssize_t)size;
  }

  // Whatever epilogue follows the closing delimiter is left to ~Message,
  // which skips the rest of a length-delimited body when closing it.
  int read_closing_delimiter() {
    return expect(estring().appends(delimiter_, "--"));
  }

 private:
  // Consumes an exact byte sequence of the framing.
  int expect(std::string_view expected) {
    while (tail_ - head_ < expected.size())
      if (fill() < 0) return -1;
    if (std::string_view(buf_ + head_, expected.size()) != expected)
      LOG_ERROR_RETURN(EIO, -1, "expected [`] in the multipart body", expected);
    head_ += expected.size();
    return 0;
  }

  // Compacts the read-ahead buffer, then reads more of the body into it.
  int fill() {
    if (head_ > 0) {
      memmove(buf_, buf_ + head_, tail_ - head_);
      tail_ -= head_;
      head_ = 0;
    }
    if (tail_ == sizeof(buf_))
      LOG_ERROR_RETURN(EIO, -1, "part header longer than ` bytes",
                       sizeof(buf_));
    auto ret = response_->read(buf_ + tail_, sizeof(buf_) - tail_);
    if (ret <= 0) LOG_ERROR_RETURN(EIO, -1, "multipart body ended unexpectedly");
    tail_ += ret;
    return 0;
  }

  Response* response_;
  estring delimiter_;
  // framing bytes read ahead, spilling over into the payload that follows.
  // ponytail: a part header longer than this fails the request instead of
  // growing the buffer; OSS sends ~80 bytes of them, boundary included.
  char buf_[512];
  size_t head_ = 0, tail_ = 0;
};

int OssClient::read_range_parts(HTTP_STACK_OP& op, std::string_view obj_path,
                                std::vector<GetRangeParameters>& ranges) {
  auto boundary = get_byteranges_boundary(op.resp.headers["Content-Type"]);
  if (boundary.empty())
    LOG_ERROR_RETURN(EINVAL, -1,
                     "` ranges of ` answered as [`], status `", ranges.size(),
                     obj_path, op.resp.headers["Content-Type"],
                     op.resp.status_code());

  ByterangesStream parts(&op.resp, boundary);
  for (size_t i = 0; i < ranges.size(); ++i) {
    auto& range = ranges[i];
    iovector_view view((struct iovec*)range.iov, range.iovcnt);
    uint64_t start = 0, end = 0;
    if (parts.next_part(start, end) < 0) return -1;
    // guaranteed by the ascending, non-overlapping range list
    if (start != (uint64_t)range.offset || end - start + 1 != view.sum())
      LOG_ERROR_RETURN(EIO, -1,
                       "part #` of ` covers [`, `], expected [`, `]", i,
                       obj_path, start, end, range.offset,
                       range.offset + view.sum() - 1);
    range.result = parts.read_payload(range.iov, range.iovcnt, view.sum());
    if (range.result != (ssize_t)view.sum()) return -1;
  }
  return parts.read_closing_delimiter();
}

int OssClient::get_object_ranges(std::string_view obj_path,
                                 std::vector<GetRangeParameters>& ranges,
                                 RequestTrace* trace) {
  if (ranges.size() < 2 || ranges.size() > OSS_MULTI_RANGE_MAX_COUNT)
    LOG_ERROR_RETURN(EINVAL, -1, "` ranges of `, must be within [2, `]",
                     ranges.size(), obj_path, OSS_MULTI_RANGE_MAX_COUNT);

  // ascending and non-overlapping, so that OSS neither reorders nor merges the
  // list, and answers with exactly one part per range
  estring range_list("bytes=");
  off_t next_offset = 0;
  for (size_t i = 0; i < ranges.size(); ++i) {
    auto& range = ranges[i];
    range.result = -1;
    iovector_view view((struct iovec*)range.iov, range.iovcnt);
    auto cnt = view.sum();
    if (cnt == 0 || range.offset < next_offset)
      LOG_ERROR_RETURN(EINVAL, -1,
                       "range #` of ` is empty or descends: [`, `)", i,
                       obj_path, range.offset, range.offset + cnt);
    next_offset = range.offset + cnt;
    range_list.appends(make_ccl(i > 0, ","), range.offset, "-",
                       next_offset - 1);
  }

  int retry_times = m_oss_options.retry_times;
  auto retry_interval = m_oss_options.retry_base_interval_us;
  bool invalidate_cache = false;
retry:
  auto oss_url = make_oss_url(obj_path);
  DEFINE_ONSTACK_OP(m_client, Verb::GET, oss_url.url());
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_RANGE_BEHAVIOR, "standard");
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_MULTI_RANGE_BEHAVIOR,
                        "multi-range");
  op.req.headers.insert("Range", range_list);
  int r = sign_and_call(op, Verb::GET, oss_url, {}, invalidate_cache, trace);
  if (r < 0) {
    if (errno == EACCES && !invalidate_cache) {
      invalidate_cache = true;
      errno = 0;
      goto retry;
    }
    return r;
  }

  r = read_range_parts(op, obj_path, ranges);
  // a truncated or garbled body deserves another round trip, a response that
  // ignores the range list does not
  if (r < 0 && errno == EIO && retry_times-- > 0) {
    photon::thread_usleep(retry_interval);
    retry_interval *= 2;
    LOG_ERROR("Retrying oss request ` `", verbstr[op.req.verb()],
              op.req.target());
    goto retry;
  }
  return r;
}

struct BatchGetResult {
  uint32_t request_count = 0;
  uint32_t success_count = 0;
  uint32_t status_code = 0;
  std::string error_msg;
};

class FrameStream;
struct Frame {
  enum class FrameKind : uint8_t { None, Data, Meta, End };

  FrameKind kind = FrameKind::None;
  uint32_t ref_id = 0;
  uint32_t payload_size = 0;
  uint32_t tail_size = 0;  // checksum size

  BatchGetResult read_end(FrameStream& stream) const;
  std::unordered_map<estring_view, estring> read_meta(
      FrameStream& stream) const;
  ssize_t read_data(FrameStream& stream, const struct iovec* iov,
                    int iovcnt) const;
  bool skip(FrameStream& stream) const;

  operator bool() const { return kind != FrameKind::None; }
};

static inline uint32_t be32_to_host(const uint8_t* p) {
  return (static_cast<uint32_t>(p[0]) << 24) |
         (static_cast<uint32_t>(p[1]) << 16) |
         (static_cast<uint32_t>(p[2]) << 8) | (static_cast<uint32_t>(p[3]));
}

class FrameStream {
 public:
  using Response = photon::net::http::Response;

  explicit FrameStream(Response* response) : response_(response) {}

  Frame next() {
    static constexpr uint32_t FRAME_DATA = 0xFF2;
    static constexpr uint32_t FRAME_META = 0xFF1;
    static constexpr uint32_t FRAME_END = 0xFF4;

    // |version| Frame-Type |  ref-id    | Payload Length|Header
    // Checksum|Payload|Payload Checksum|
    // |<1---->| <--3 bytes>|<--4 bytes->| <--4 bytes--->|<--4
    // bytes-----><-n/a--><--4 bytes----->|

    uint8_t header[16];
    if (!read_exact(header, sizeof(header))) {
      return {};
    }

    header[0] = 0;  // ignore version bit

    uint32_t type = be32_to_host(header);
    if (type != FRAME_DATA && type != FRAME_META && type != FRAME_END) {
      return {};
    }

    Frame frame;
    frame.ref_id = be32_to_host(header + 4);
    frame.payload_size = be32_to_host(header + 8);
    frame.tail_size = 4;

    if (type == FRAME_DATA)
      frame.kind = Frame::FrameKind::Data;
    else if (type == FRAME_META)
      frame.kind = Frame::FrameKind::Meta;
    else if (type == FRAME_END)
      frame.kind = Frame::FrameKind::End;
    return frame;
  }

 private:
  BatchGetResult read_end_frame(const Frame& frame) {
    size_t total = frame.payload_size + frame.tail_size;
    std::vector<uint8_t> buf(total);
    if (total < 12 || !read_exact(buf.data(), total)) return {};

    BatchGetResult ret;
    ret.request_count = be32_to_host(buf.data());
    ret.success_count = be32_to_host(buf.data() + 4);
    ret.status_code = be32_to_host(buf.data() + 8);

    if (frame.payload_size > 12) {
      ret.error_msg.assign(reinterpret_cast<const char*>(buf.data() + 12),
                           frame.payload_size - 12);
    }
    // ignore last 4 bytes (checksum)
    return ret;
  }
  std::unordered_map<estring_view, estring> read_meta_frame(
      const Frame& frame) {
    size_t total = frame.payload_size + frame.tail_size;
    std::vector<char> buf(total);
    if (!read_exact(reinterpret_cast<uint8_t*>(buf.data()), total)) return {};

    static const std::unordered_set<estring_view> headers = {
        "x-oss-storage-class", "x-oss-hash-crc64ecma",
        "x-oss-object-type",   "ETag",
        "x-oss-response-code", "Last-Modified",
        "x-oss-object-size"};

    estring_view meta_str(buf.data(), frame.payload_size);
    std::unordered_map<estring_view, estring> meta;
    for (auto line : meta_str.split_lines()) {
      auto pos = line.find(':');
      if (pos == estring_view::npos) continue;
      estring_view key(line.substr(0, pos));
      auto it = headers.find(key.trim());
      if (it == headers.end()) continue;
      estring_view val(line.substr(pos + 1));
      meta.emplace(*it, photon::net::http::url_unescape(val.trim()));
    }
    return meta;
  }

  ssize_t read_data_frame(const Frame& frame, const struct iovec* iov,
                          int iovcnt) {
    ssize_t ret = response_->readv(iov, iovcnt);
    if (ret < 0 || static_cast<size_t>(ret) != frame.payload_size) {
      LOG_ERROR("Data frame mismatch: expected `, got `", frame.payload_size,
                ret);
      return ret < 0 ? ret : -1;
    }
    if (!skip_bytes(frame.tail_size))
      LOG_ERROR_RETURN(EIO, -1, "Failed to skip data frame tail");
    return ret;
  }

  bool skip_frame(const Frame& frame) {
    return skip_bytes(frame.payload_size + frame.tail_size);
  }

  bool read_exact(uint8_t* buf, size_t n) {
    while (n > 0) {
      size_t got = response_->read(buf, n);
      if (got == 0 || got > n) return false;
      buf += got;
      n -= got;
    }
    return true;
  }

  bool skip_bytes(size_t n) {
    std::vector<uint8_t> dummy(std::min(n, size_t(128 * 1024)));
    while (n > 0) {
      size_t chunk = std::min(n, dummy.size());
      if (!read_exact(dummy.data(), chunk)) return false;
      n -= chunk;
    }
    return true;
  }

  Response* response_ = nullptr;
  friend struct Frame;
};

BatchGetResult Frame::read_end(FrameStream& stream) const {
  assert(kind == FrameKind::End);
  return stream.read_end_frame(*this);
}

std::unordered_map<estring_view, estring> Frame::read_meta(
    FrameStream& stream) const {
  assert(kind == FrameKind::Meta);
  return stream.read_meta_frame(*this);
}

ssize_t Frame::read_data(FrameStream& stream, const struct iovec* iov,
                         int iovcnt) const {
  assert(kind == FrameKind::Data);
  return stream.read_data_frame(*this, iov, iovcnt);
}

bool Frame::skip(FrameStream& stream) const { return stream.skip_frame(*this); }

int OssClient::batch_get_objects(std::vector<GetObjectParameters>& params,
                                 RequestTrace* trace) {
  static std::string_view req_head = "<GetObjectsRequest>";
  static std::string_view req_tail = "</GetObjectsRequest>";
  estring req_list;
  for (size_t i = 0; i < params.size(); i++) {
    iovector_view view((struct iovec*)params[i].iov, params[i].iovcnt);
    auto cnt = view.sum();
    req_list.appends("<Object><ObjectName>", xml_escape(params[i].object),
                     "</ObjectName><Range>bytes=", params[i].offset, "-",
                     params[i].offset + cnt - 1, "</Range><RefId>", i + 1,
                     "</RefId></Object>");
    params[i].result = -1;
  }

  struct iovec iov[3] = {{(void*)req_head.data(), req_head.size()},
                         {(void*)req_list.data(), req_list.size()},
                         {(void*)req_tail.data(), req_tail.size()}};
  iovector_view body_view(iov, 3);

  auto oss_url = make_oss_url("/");
  auto md5 = md5_base64(body_view);

  DEFINE_CONST_STATIC_ORDERED_STRING_KV(query_params,
                                        {// must appear in dictionary order!
                                         {OSS_PARAM_KEY_BATCH_GET, ""}});

  DEFINE_ONSTACK_OP(m_client, Verb::POST, oss_url.append_params(query_params));
  op.req.headers.insert(OSS_HEADER_KEY_CONTENT_MD5, md5);
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_RANGE_BEHAVIOR, "standard");
  op.req.headers.content_length(body_view.sum());
  op.body_writer = {&body_view, &body_writer_cb};

  int r = sign_and_call(op, Verb::POST, oss_url, query_params, false, trace);
  if (r < 0) return r;

  uint32_t read_good_cnt = 0;
  FrameStream stream(&op.resp);
  while (auto frame = stream.next()) {
    if (frame.kind == Frame::FrameKind::Meta) {
      auto& param = params[frame.ref_id - 1];
      auto meta_map = frame.read_meta(stream);
      auto it = meta_map.find("x-oss-response-code");
      if (it != meta_map.end()) {
        auto status_code = estring_view(it->second).to_int64();
        param.result = 0;
        if (status_code / 100 != 2) {
          param.result = -error_http_status_to_errno(status_code);
        }
        if (param.result < 0) {
          LOG_ERROR("Object ` failed with status code `", param.object,
                    status_code);
        }
      }

      if (param.meta && param.result == 0) {
        param.meta->set_type(meta_map["x-oss-object-type"]);
        param.meta->set_etag(meta_map["ETag"]);
        param.meta->set_storage_class(meta_map["x-oss-storage-class"]);
        param.meta->set_mtime(
            get_lastmodified(meta_map["Last-Modified"]));
        param.meta->set_crc64(
            estring_view(meta_map["x-oss-hash-crc64ecma"]).to_uint64());
        param.meta->set_size(
            estring_view(meta_map["x-oss-object-size"]).to_int64());
      }
    } else if (frame.kind == Frame::FrameKind::Data) {
      auto& param = params[frame.ref_id - 1];
      if (param.result < 0) {
        std::string msg(frame.payload_size, 0);
        iovec iov = {&msg[0], frame.payload_size};
        r = frame.read_data(stream, &iov, 1);
        if (r < 0) return r;
        LOG_ERROR("reading object ` failed with result ` msg `", param.object,
                  param.result, msg);
        continue;
      }

      iovector_view view((struct iovec*)param.iov, param.iovcnt);
      if (view.sum() < frame.payload_size) {
        LOG_ERROR("Skip object ` data frame expected `, got `, result `",
                  param.object, view.sum(), frame.payload_size, param.result);
        if (!frame.skip(stream))
          LOG_ERROR_RETURN(EIO, -1, "Failed to skip data frame");
        continue;
      }

      if (view.sum() > frame.payload_size) {
        // rebuild the iovs if the returned data is less than expected.
        std::vector<iovec> iovs;
        iovs.reserve(param.iovcnt);
        size_t remaining = frame.payload_size;
        for(auto i = 0; i < param.iovcnt; i++) {
          auto cur = std::min(remaining, param.iov[i].iov_len);
          iovs.push_back({param.iov[i].iov_base, cur});
          remaining -= cur;
          if (remaining == 0) break;
        }

        r = frame.read_data(stream, &iovs[0], iovs.size());
      } else {
        r = frame.read_data(stream, param.iov, param.iovcnt);
      }

      if (r < 0) return r;
      param.result = r;
      read_good_cnt++;
    } else {
      auto result = frame.read_end(stream);
      // The End frame is the last one; skip the trailing bytes of the
      // chunked body (terminating chunk 0\r\n\r\n) if necessary, so that
      // close() sees a finished body and the keep-alive connection can
      // be pooled for reuse instead of being dropped.
      // TODO: remove this workaround once ChunkedBodyReadStream consumes
      // the terminating chunk automatically on exact-sized reads.
      char drain_buf[64];
      op.resp.read(drain_buf, sizeof(drain_buf));
      LOG_DEBUG("End frame status code ` request cnt ` success cnt `",
                result.status_code, result.request_count, result.success_count);
      if (read_good_cnt != result.success_count) {
        LOG_ERROR("Mismatch between read good cnt ` and success cnt `",
                  read_good_cnt, result.success_count);
        return -1;
      }
      return result.success_count;
    }
  }
  return 0;
}

ssize_t OssClient::put_object(std::string_view object, size_t cnt,
                              BodyWriter writer, ObjectUploadOptions& opts,
                              RequestTrace* trace) {
  auto oss_url = make_oss_url(object);
  auto content_type = lookup_mime_type(object);

  DEFINE_ONSTACK_OP(m_client, Verb::PUT, oss_url.url());
  if (!content_type.empty()) {
    op.req.headers.insert(OSS_HEADER_KEY_CONTENT_TYPE, content_type);
  }
  op.req.headers.content_length(cnt);
  auto body_writer_wrapper = [&writer, cnt](photon::net::http::Request* req) -> ssize_t {
    ssize_t n = writer(req);
    if (n != (ssize_t)cnt) {
      LOG_ERROR_RETURN(0, -1, "body writer wrote `, expected `", n, cnt);
    }
    return 0;
  };
  op.body_writer = body_writer_wrapper;
  int r = sign_and_call(op, Verb::PUT, oss_url, {}, false, trace);
  if (r < 0) return r;
  r = verify_crc64_if_needed(op, oss_url.object(), opts.expected_crc64);
  if (r < 0) return r;
  fill_upload_response(op, opts);
  return cnt;
}

ssize_t OssClient::append_object(std::string_view object,
                                 const struct iovec* iov, int iovcnt,
                                 off_t position, ObjectUploadOptions& opts,
                                 RequestTrace* trace) {
  iovector_view view((struct iovec*)iov, iovcnt);
  auto cnt = view.sum();

  auto oss_url = make_oss_url(object);

  estring position_str = std::to_string(position);

  // must appear in dictionary order!
  DEFINE_ORDERED_STRING_KV(
      query_params,
      {{OSS_PARAM_KEY_APPEND, ""}, {OSS_PARAM_KEY_POSITION, position_str}});

  DEFINE_ONSTACK_OP(m_client, Verb::POST, oss_url.append_params(query_params));
  auto content_type = lookup_mime_type(object);
  if (!content_type.empty()) {
    op.req.headers.insert(OSS_HEADER_KEY_CONTENT_TYPE, content_type);
  }
  op.req.headers.content_length(cnt);
  op.body_writer = {&view, &body_writer_cb};
  int r = sign_and_call(op, Verb::POST, oss_url, query_params, false, trace);
  if (r < 0) return r;
  r = verify_crc64_if_needed(op, oss_url.object(), opts.expected_crc64);
  if (r < 0) return r;
  fill_upload_response(op, opts);
  return cnt;
}

int OssClient::copy_object(std::string_view src_object,
                           std::string_view dst_object,
                           ObjectCopyOptions& opts) {
  auto src_oss_url = make_oss_url(src_object);
  auto dst_oss_url = make_oss_url(dst_object);

  return do_copy_object(src_oss_url, dst_oss_url, opts);
}

struct oss_multipart_context {
  estring obj_path;
  std::string upload_id;
  std::vector<std::pair<int, std::string>> part_list;
  photon::spinlock lock;
};

int OssClient::init_multipart_upload(std::string_view object, void** context) {
  auto oss_url = make_oss_url(object);

  DEFINE_CONST_STATIC_ORDERED_STRING_KV(query_params,
                                        {// must appear in dictionary order!
                                         {OSS_PARAM_KEY_UPLOADS, ""}});

  DEFINE_ONSTACK_OP(m_client, Verb::POST, oss_url.append_params(query_params));

  auto content_type = lookup_mime_type(object);
  if (!content_type.empty())
    op.req.headers.insert(OSS_HEADER_KEY_CONTENT_TYPE, content_type);

  int r = sign_and_call(op, Verb::POST, oss_url, query_params);
  if (r < 0) return r;

  auto reader = get_xml_node(op);
  if (!reader) LOG_ERROR_RETURN(EINVAL, -1, "failed to parse xml resp_body");
  auto upload_id = NodeStrValue(reader["InitiateMultipartUploadResult"]["UploadId"]);
  if (!upload_id.has_value())
    LOG_ERROR_RETURN(EINVAL, -1, "invalid response with no upload id provided");

  oss_multipart_context* ctx = new oss_multipart_context;
  ctx->obj_path.appends(object);
  ctx->upload_id = static_cast<estring_view>(upload_id);

  *context = ctx;
  return 0;
}

ssize_t OssClient::upload_part(void* context, size_t cnt,
                               int part_number, BodyWriter writer,
                               ObjectUploadOptions& opts) {
  assert(context);

  oss_multipart_context* ctx = (oss_multipart_context*)context;
  assert(!ctx->upload_id.empty());

  estring part_nums_str = std::to_string(part_number);

  // must appear in dictionary order!
  DEFINE_ORDERED_STRING_KV(query_params,
                           {{OSS_PARAM_KEY_PART_NUMBER, part_nums_str},
                            {OSS_PARAM_KEY_UPLOAD_ID, ctx->upload_id}});

  auto oss_url = make_oss_url(ctx->obj_path);

  DEFINE_ONSTACK_OP(m_client, Verb::PUT, oss_url.append_params(query_params));

  op.req.headers.content_length(cnt);
  auto body_writer_wrapper = [&writer, cnt](photon::net::http::Request* req) -> ssize_t {
    ssize_t n = writer(req);
    if (n != (ssize_t)cnt) {
      LOG_ERROR_RETURN(0, -1, "body writer wrote `, expected `", n, cnt);
    }
    return 0;
  };
  op.body_writer = body_writer_wrapper;
  int r = sign_and_call(op, Verb::PUT, oss_url, query_params);
  if (r < 0) return r;

  auto etag = op.resp.headers["ETag"];
  if (etag.empty())
    LOG_ERROR_RETURN(EINVAL, -1, "unexpected response with empty etag");

  r = verify_crc64_if_needed(op, oss_url.object(), opts.expected_crc64);
  if (r < 0) return r;

  SCOPED_LOCK(ctx->lock);
  ctx->part_list.emplace_back(part_number, etag);
  return cnt;
}

int OssClient::upload_part_copy(void* context, off_t offset, size_t count,
                                int part_number, std::string_view from,
                                ObjectPartCopyOptions& opts) {
  assert(context);
  oss_multipart_context* ctx = (oss_multipart_context*)context;
  assert(!ctx->upload_id.empty());

  auto oss_url = make_oss_url(ctx->obj_path);

  estring part_num_str = std::to_string(part_number);

  // must appear in dictionary order!
  DEFINE_ORDERED_STRING_KV(query_params,
                           {{OSS_PARAM_KEY_PART_NUMBER, part_num_str},
                            {OSS_PARAM_KEY_UPLOAD_ID, ctx->upload_id}});

  estring oss_copy_source;
  if (from.empty()) {  // just copy myself
    oss_copy_source.appends("/", oss_url.bucket(), "/", oss_url.object(true));
  } else {
    oss_copy_source.appends("/", oss_url.bucket(), "/",
                            photon::net::http::url_escape(from));
  }
  std::string range = "bytes=" + std::to_string(offset) + "-" +
                      std::to_string(offset + count - 1);

  DEFINE_ONSTACK_OP(m_client, Verb::PUT, oss_url.append_params(query_params));
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_COPY_SOURCE, oss_copy_source);
  op.req.headers.insert(OSS_HEADER_KEY_X_OSS_COPY_SOURCE_RANGE, range);
  opts.crc64.reset();
  int r = sign_and_call(op, Verb::PUT, oss_url, query_params);
  if (r < 0) return r;

  uint64_t crc64;
  if (get_resp_crc64(op, &crc64)) opts.crc64.set(crc64);

  auto reader = get_xml_node(op);
  if (!reader) LOG_ERROR_RETURN(EINVAL, -1, "failed to parse xml resp_body");
  auto etag = NodeStrValue(reader["CopyPartResult"]["ETag"]);
  if (!etag.has_value())
    LOG_ERROR_RETURN(EINVAL, -1, "invalid response with no etag provided");

  if ((static_cast<estring_view>(etag)).empty())
    LOG_ERROR_RETURN(EINVAL, -1, "unexpected response with empty etag");

  SCOPED_LOCK(ctx->lock);
  ctx->part_list.emplace_back(part_number, static_cast<estring_view>(etag));
  return 0;
}

int OssClient::complete_multipart_upload(void* context,
                                         ObjectUploadOptions& opts) {
  assert(context);

  oss_multipart_context* ctx = (oss_multipart_context*)context;
  assert(!ctx->upload_id.empty());

  estring req_body;
  req_body.appends("<CompleteMultipartUpload>");

  std::sort(ctx->part_list.begin(), ctx->part_list.end(),
            [](auto& a, auto& b) { return a.first < b.first; });
  for (auto& part : ctx->part_list) {
    req_body.appends(
        "<Part>"
        "<PartNumber>",
        part.first,
        "</PartNumber>"
        "<ETag>",
        part.second,
        "</ETag>"
        "</Part>");
  }
  req_body.appends("</CompleteMultipartUpload>");

  struct iovec iov{(void*)(req_body.data()), req_body.size()};

  iovector_view view(&iov, 1);
  auto oss_url = make_oss_url(ctx->obj_path);

  DEFER(delete ctx);

  // must appear in dictionary order!
  DEFINE_ORDERED_STRING_KV(query_params,
                           {{OSS_PARAM_KEY_UPLOAD_ID, ctx->upload_id}});
  DEFINE_ONSTACK_OP(m_client, Verb::POST, oss_url.append_params(query_params));
  op.req.headers.content_length(req_body.size());
  op.body_writer = {&view, &body_writer_cb};
  int r = sign_and_call(op, Verb::POST, oss_url, query_params);
  if (r < 0) return r;
  r = verify_crc64_if_needed(op, oss_url.object(), opts.expected_crc64);
  if (r < 0) return r;
  fill_upload_response(op, opts);
  return r;
}

int OssClient::abort_multipart_upload(void* context) {
  assert(context);

  oss_multipart_context* ctx = (oss_multipart_context*)context;
  assert(!ctx->upload_id.empty());

  auto oss_url = make_oss_url(ctx->obj_path);

  DEFER(delete ctx);

  // must appear in dictionary order!
  DEFINE_ORDERED_STRING_KV(query_params,
                           {{OSS_PARAM_KEY_UPLOAD_ID, ctx->upload_id}});

  DEFINE_ONSTACK_OP(m_client, Verb::DELETE,
                    oss_url.append_params(query_params));
  return sign_and_call(op, Verb::DELETE, oss_url, query_params);
}

int OssClient::get_object_meta(std::string_view object, ObjectMeta& meta) {
  DEFINE_CONST_STATIC_ORDERED_STRING_KV(query_params,
                                        {
                                            // must appear in dictionary order!
                                            {OSS_PARAM_KEY_OBJECT_META, ""},
                                        });
  auto oss_url = make_oss_url(object);
  DEFINE_ONSTACK_OP(m_client, Verb::HEAD, oss_url.append_params(query_params));
  int r = sign_and_call(op, Verb::HEAD, oss_url, query_params);
  if (r < 0) return r;
  return fill_meta(op, meta);
}

int OssClient::delete_object(std::string_view obj_path) {
  auto oss_url = make_oss_url(obj_path);
  return do_delete_object(oss_url);
}

void OssClient::set_credentials(CredentialParameters&& credentials) {
  if (m_authenticator) {
    m_authenticator->set_credentials(std::move(credentials));
  }
}

#undef OssClient

class BasicAuthenticator : public Authenticator {
  char m_gmt_date[GMT_DATE_LIMIT];
  char m_gmt_date_iso8601[GMT_DATE_LIMIT];
  time_t m_last_tim = 0;
  CredentialParameters m_credentials;
  void append_query_params(estring& s, const StringKV& params,
                           bool need_question_mark = true) {
    if (!params.empty()) {
      auto it = params.begin();
      s.appends(make_ccl(need_question_mark, "?"), it->first,
                make_ccl(!it->second.empty(), "=", it->second));
      while (++it != params.end()) {
        s.appends("&", it->first,
                  make_ccl(!it->second.empty(), "=", it->second));
      }
    }
  }

  void append_headers(estring& s, const photon::net::http::Headers& header_map,
                      bool v4_signature) {
    for (auto kv : header_map) {
      if (kv.first.substr(0, 5) != "x-oss" &&
          (!v4_signature || (kv.first != OSS_HEADER_KEY_CONTENT_MD5 &&
                             kv.first != OSS_HEADER_KEY_CONTENT_TYPE)))
        continue;
      s.appends(kv.first, ":", kv.second, "\n");
    }
  }

  void sign_v1(photon::net::http::Headers& headers,
               const Authenticator::SignParameters& params,
               const CredentialParameters& cred) {
    estring auth, data2sign;
    std::string_view ak = cred.accessKeyId;
    std::string_view sk = cred.accessKeySecret;
    std::string_view token = cred.securityToken;

    update_gmt_date();

    std::string_view method = photon::net::http::verbstr[params.verb];
    auto content_md5 = headers.get_value(OSS_HEADER_KEY_CONTENT_MD5);
    auto content_type = headers.get_value(OSS_HEADER_KEY_CONTENT_TYPE);

    data2sign.appends(method, "\n", content_md5, "\n", content_type, "\n",
                      m_gmt_date, "\n");

    if (!token.empty()) {
      headers.insert("x-oss-security-token", token);
    }
    append_headers(data2sign, headers, false);

    data2sign.appends("/", params.bucket, "/", params.object);

    // complete this list if needed. currently it's for ossfs use only.
    // must appear in dictionary order!
    const static std::string_view sub_resources[] = {
        OSS_PARAM_KEY_APPEND,      OSS_PARAM_KEY_CONTINUATION_TOKEN,
        OSS_PARAM_KEY_DELETE,      OSS_PARAM_KEY_OBJECT_META,
        OSS_PARAM_KEY_PART_NUMBER, OSS_PARAM_KEY_POSITION,
        OSS_PARAM_KEY_SYMLINK,     OSS_PARAM_KEY_UPLOAD_ID,
        OSS_PARAM_KEY_UPLOADS,     OSS_PARAM_KEY_BATCH_GET
    };

    if (params.query_params.size()) {
      DEFINE_APPENDABLE_ORDERED_STRING_KV(sub_params, LEN(sub_resources), {{}});
      for (auto x : sub_resources) {  // x is ordered
        auto it = params.query_params.find(x);
        if (it != params.query_params.end()) {
          sub_params.append(*it);
        }
      }
      // skip the 1st empty key
      append_query_params(data2sign,
                          StringKV(sub_params.begin() + 1, sub_params.end()));
    }
    // LOG_INFO("data2sign is `", data2sign);

    estring signature;
    net::Base64Encode(HMAC_SHA1(sk, data2sign), signature);

    auth.appends("OSS ", ak, ":", signature);
    headers.insert("Authorization", auth);
    headers.insert("Date", m_gmt_date);
  }

  void sign_v4(photon::net::http::Headers& headers,
               const Authenticator::SignParameters& params,
               const CredentialParameters& cred) {
    estring auth, canonical_request, string2sign, signing_key;
    std::string_view ak = cred.accessKeyId;
    std::string_view sk = cred.accessKeySecret;
    std::string_view token = cred.securityToken;

    update_gmt_date();

    std::string_view method = photon::net::http::verbstr[params.verb];
    canonical_request.appends(
        method, "\n", "/", params.bucket, "/",
        photon::net::http::url_escape(params.object, false), "\n");
    if (params.query_params.size()) {
      append_query_params(canonical_request, params.query_params, false);
    }

    canonical_request.appends("\n");

    // headers are aloso sorted in lexicographical order
    // header1:value1\n
    // header2:value2\n
    // StringKV header_map = headers;
    headers.insert("x-oss-content-sha256", "UNSIGNED-PAYLOAD");
    headers.insert("x-oss-date", m_gmt_date_iso8601);
    if (!token.empty()) {
      headers.insert("x-oss-security-token", token);
    }
    append_headers(canonical_request, headers, true);

    canonical_request.appends("\n", "\n" /*no additional headers*/,
                              "UNSIGNED-PAYLOAD");

    string2sign.appends("OSS4-HMAC-SHA256\n", m_gmt_date_iso8601, "\n",
                        estring_view(m_gmt_date_iso8601, 8), "/", params.region,
                        "/oss/aliyun_v4_request\n",
                        sha256_hash(canonical_request));

    auto signature = hex(HMAC_SHA256(
        HMAC_SHA256(
            HMAC_SHA256(
                HMAC_SHA256(HMAC_SHA256(estring("aliyun_v4").appends(sk),
                                        estring_view(m_gmt_date_iso8601, 8)),
                            params.region),
                "oss"),
            "aliyun_v4_request"),
        string2sign));

    // LOG_INFO("string2sing ` canonical request `", string2sign,
    // canonical_request);

    // Authorization: "OSS4-HMAC-SHA256 Credential=" + AccessKeyId + "/" +
    // SignDate + "/" + SignRegion + "/oss/aliyun_v4_request," + [
    // "AdditionalHeaders=" + AdditionalHeadersVal + "," ] + "Signature=" +
    // SignatureVal
    auth.appends("OSS4-HMAC-SHA256 Credential=", ak, "/",
                 estring_view(m_gmt_date_iso8601, 8), "/", params.region,
                 "/oss/aliyun_v4_request,", "Signature=", signature);
    headers.insert("Authorization", auth);
  }

  std::string hex(std::string_view bytes) {
    static const std::string hex_map = "0123456789abcdef";
    std::string hex_data;
    hex_data.reserve(bytes.size() * 2);
    for (unsigned char c : bytes) {
      hex_data += hex_map[c >> 4];
      hex_data += hex_map[c & 0xf];
    }
    return hex_data;
  }

  std::string sha256_hash(std::string_view data) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    sha256 shax(data);
    shax.finalize(hash);
    return hex({(char*)hash, SHA256_DIGEST_LENGTH});
  }

  void update_gmt_date() {  // avoid updating GMT Time every time
    std::time_t now = std::time(nullptr);
    if (now == m_last_tim) return;
    struct tm tm{};
    if (gmtime_r(&now, &tm)) {
      m_last_tim = now;
      strftime(m_gmt_date, GMT_DATE_LIMIT, "%a, %d %b %Y %H:%M:%S GMT", &tm);
      strftime(m_gmt_date_iso8601, GMT_DATE_LIMIT, "%Y%m%dT%H%M%SZ", &tm);
    }
  }

 public:
  BasicAuthenticator(CredentialParameters&& credentials)
      : m_credentials(std::move(credentials)) {}

  void set_credentials(CredentialParameters&& credentials) {
    m_credentials = std::move(credentials);
  }

  int sign(photon::net::http::Headers& headers,
           const Authenticator::SignParameters& params) {
    if (params.region.empty()) {
      sign_v1(headers, params, m_credentials);
    } else {
      sign_v4(headers, params, m_credentials);
    }
    return 0;
  }
};

class CachedAuthenticator : public Authenticator {
  Authenticator* m_auth = nullptr;
  uint32_t m_cached_ttl_secs = 300;
  using CachedObjHeader = std::vector<std::pair<std::string, std::string>>;
  std::shared_ptr<ObjectCache<std::string, CachedObjHeader*>> m_cached_headers;

 public:
  CachedAuthenticator(Authenticator* auth, uint32_t cache_ttl_secs)
      : m_auth(auth),
        m_cached_ttl_secs(cache_ttl_secs),
        m_cached_headers(
            std::make_shared<ObjectCache<std::string, CachedObjHeader*>>(
                1000ll * 1000 * cache_ttl_secs)) {}
  ~CachedAuthenticator() { delete m_auth; }
  int sign(photon::net::http::Headers& headers,
           const Authenticator::SignParameters& params) override {
    // only get obj range request among our supported interfaces will fall into
    // this catagory currently
    bool can_use_cache =
        params.verb == Verb::GET && params.query_params.empty();
    if (!can_use_cache) return m_auth->sign(headers, params);

    // every x-oss-* header is signed, so the ones already set by the caller
    // (range behaviors, custom headers) are part of the cache identity.
    // Headers keeps its index sorted by name, so the key does not depend on
    // the order in which the caller inserted them.
    estring cached_key;
    cached_key.appends(params.bucket, "/", params.object);
    for (auto kv : headers) {
      if (estring_view(kv.first).istarts_with("x-oss")) {
        cached_key.appends("\n", kv.first, ":", kv.second);
      }
    }

    static const std::vector<std::string_view> to_cache_keys = {
        "Authorization", "x-oss-security-token", "x-oss-date",
        "x-oss-content-sha256", "Date" /*v1 signature needed*/};

    bool evict_cache = params.invalidate_cache;
    int r = 0;

    auto ctor = [&]() -> CachedObjHeader* {
      if (evict_cache) evict_cache = false;
      r = m_auth->sign(headers, params);
      if (r != 0) return nullptr;
      auto* cached = new CachedObjHeader();
      for (const auto& k : to_cache_keys) {
        auto it = headers.find(k);
        if (it != headers.end()) {
          cached->emplace_back(k, it.second());
        }
      }
      // LOG_INFO("cached headers for key ` `", cached_key,  cached);
      return cached;
    };

    bool should_retry = false;
    do {
      should_retry = false;
      auto cached = m_cached_headers->borrow(cached_key, ctor);
      if (cached) {
        if (evict_cache) {
          // LOG_INFO("recycling cached headers for key `", cached_key);
          cached.recycle(true);
          evict_cache = false;
          should_retry = true;
          continue;
        }

        if (!cached->empty()) {
          for (const auto& kv : *cached) {
            headers.insert(kv.first, kv.second);
          }
          // LOG_INFO("using cached headers for key `", cached_key);
          return 0;
        }
      }
    } while (should_retry);
    return r;
  }

  void set_credentials(CredentialParameters&& credentials) override {
    // create one new cache instance to discard all the old entries
    m_cached_headers =
        std::make_shared<ObjectCache<std::string, CachedObjHeader*>>(
            1000ll * 1000 * m_cached_ttl_secs);
    m_auth->set_credentials(std::move(credentials));
  }
};

Client* new_oss_client(const ClientOptions& opt, Authenticator* auth) {
  return new OssClientImpl(opt, auth);
}

Client* new_oss_client(const ClientOptions& opt, uint32_t cache_ttl_secs,
                       CredentialParameters&& credentials) {
  auto auth = new_basic_oss_authenticator(std::move(credentials));
  if (!auth) return nullptr;
  if (cache_ttl_secs) auth = new_cached_oss_authenticator(auth, cache_ttl_secs);
  return new_oss_client(opt, auth);
}

Authenticator* new_basic_oss_authenticator(CredentialParameters&& credentials) {
  return new BasicAuthenticator(std::move(credentials));
}

Authenticator* new_cached_oss_authenticator(Authenticator* auth,
                                            uint32_t cache_ttl_secs) {
  if (cache_ttl_secs) return new CachedAuthenticator(auth, cache_ttl_secs);
  return auth;
}

}  // namespace objstore
}  // namespace photon
