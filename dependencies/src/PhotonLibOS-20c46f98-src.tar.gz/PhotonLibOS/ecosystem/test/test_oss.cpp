#include <gflags/gflags.h>
#include <gtest/gtest.h>
#include <photon/common/alog.h>
#include <photon/common/alog-stdstring.h>
#include <photon/common/checksum/crc64ecma.h>
#include <photon/common/estring.h>
#include <photon/common/stream.h>
#include <photon/photon.h>
#include <photon/thread/thread.h>

#include <fcntl.h>
#include <unistd.h>

#include <chrono>
#include <cstring>
#include <cstdlib>
#include <string>
#include <random>
#include <algorithm>

#include "../oss.h"

DEFINE_string(ak, "", "OSS Access Key ID");
DEFINE_string(sk, "", "OSS Access Key Secret");
DEFINE_string(endpoint, "", "OSS Endpoint");
DEFINE_string(bucket, "", "OSS Bucket Name");
DEFINE_string(region, "", "OSS Region");
DEFINE_bool(path_style, false, "Use path-style requests");

using namespace photon::objstore;

class BasicAuthOssTest : public ::testing::Test {
 protected:
  Client* client = nullptr;
  virtual void CreateOssClient(const ClientOptions& opts) {
    auto auth = new_basic_oss_authenticator({FLAGS_ak, FLAGS_sk, ""});
    client = new_oss_client(opts, auth);
    ASSERT_NE(client, nullptr) << "Failed to create OSS client";
  }
  void SetUp() override {
    auto random_suffix =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch())
            .count();
    bucket_prefix_ = "test_prefix_" + std::to_string(random_suffix) + "/";

    ClientOptions opts_;
    opts_.bucket = FLAGS_bucket;
    opts_.endpoint = FLAGS_endpoint;
    opts_.max_list_ret_cnt = 2;
    opts_.path_style = FLAGS_path_style;

    // v4 signature with non-empty region, otherwise v1 signature.
    opts_.region = FLAGS_region;

    if (random_suffix % 2) {
      opts_.custom_headers = {{"x-custom-trace-id", "test-run-" + std::to_string(random_suffix)},
                              {"x-oss-custom-client", "photon-test"}};
    }

    CreateOssClient(opts_);
  }

  void TearDown() override {
    if (client && !bucket_prefix_.empty()) {
      std::vector<std::string> objects;
      auto cb = [&](const ListObjectsCBParameters& cb) {
        objects.emplace_back(std::string(cb.key));
        return 0;
      };
      int ret = client->list_objects(bucket_prefix_, cb);
      ASSERT_EQ(ret, 0);

      if (objects.size()) {
        if (rand() % 2) {
          client->delete_objects(
              std::vector<std::string_view>(objects.begin(), objects.end()));
        } else {
          for (auto& obj : objects) {
            ret = client->delete_object(obj);
            ASSERT_EQ(ret, 0);
          }
        }
        objects.clear();
        ret = client->list_objects(bucket_prefix_, cb);
        ASSERT_EQ(ret, 0);
        ASSERT_EQ(objects.size(), 0);
      }
    }
    if (client) delete client;
  }

  estring get_real_test_path(std::string_view suffix) {
    estring path;
    if (suffix.size() && suffix.front() == '/') suffix.remove_prefix(1);
    path.appends(bucket_prefix_, suffix);
    return path;
  }

  void list_objects();
  void put_and_get_meta();
  void bucket_operations();
  void copy_and_rename();
  void append_and_get();
  void multipart();
  void symlink();
  void batch_get_objects();
  void get_object_ranges();
  void upload_with_options();
  void fd_get_and_put();
  void fd_multipart();
  void retry_get_and_put();
  void buf_put_and_get();
  void buf_multipart();
  void request_trace();

 private:
  std::string bucket_prefix_;
};

class CachedAuthOssTest : public BasicAuthOssTest {
 protected:
  void CreateOssClient(const ClientOptions& opts) override {
    auto auth = new_basic_oss_authenticator({FLAGS_ak, FLAGS_sk, ""});
    auth = new_cached_oss_authenticator(auth, 3 /*ttl*/);
    client = new_oss_client(opts, auth);
    ASSERT_NE(client, nullptr) << "Failed to create OSS client";
  }

  void repeatedly_get();
};

class RandInvalidateCacheAuthenticator : public Authenticator {
  Authenticator* auth_ = nullptr;

 public:
  RandInvalidateCacheAuthenticator(Authenticator* auth) : auth_(auth) {}
  ~RandInvalidateCacheAuthenticator() { delete auth_; }
  virtual int sign(photon::net::http::Headers& headers,
                   const SignParameters& params) override {
    auto new_params = params;
    new_params.invalidate_cache = rand() % 2;
    return auth_->sign(headers, new_params);
  }

  virtual void set_credentials(CredentialParameters&& credentials) override {
    auth_->set_credentials(std::move(credentials));
  }
};

class CustomCachedAuthOssTest : public CachedAuthOssTest {
 protected:
  void CreateOssClient(const ClientOptions& opts) override {
    auto auth = new_basic_oss_authenticator({FLAGS_ak, FLAGS_sk, ""});
    auth = new_cached_oss_authenticator(auth, 3 /*ttl*/);
    client = new_oss_client(opts, new RandInvalidateCacheAuthenticator(auth));
    ASSERT_NE(client, nullptr) << "Failed to create OSS client";
  }
};

void BasicAuthOssTest::bucket_operations() {
  auto suffix =
      std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::system_clock::now().time_since_epoch())
          .count();
  estring bucket_name;
  bucket_name.appends("photon-test-", suffix);

  ClientOptions opts;
  opts.bucket = bucket_name;
  opts.endpoint = FLAGS_endpoint;
  opts.region = FLAGS_region;
  opts.path_style = FLAGS_path_style;
  auto auth = new_basic_oss_authenticator({FLAGS_ak, FLAGS_sk, ""});
  Client* bclient = new_oss_client(opts, auth);
  ASSERT_NE(bclient, nullptr);
  DEFER(delete bclient);
  // best-effort cleanup in case an assertion fails mid-test
  DEFER({
    bclient->delete_object("bucket_operations/testfile");
    bclient->delete_bucket();
  });

  int ret = bclient->put_bucket();
  ASSERT_EQ(ret, 0);

  // the new bucket is usable right away
  char buf[3] = {1};
  iovec iov{buf, 3};
  auto crc64 = crc64ecma(buf, 3, 0);
  ret = bclient->put_object("bucket_operations/testfile", &iov, 1, &crc64);
  ASSERT_EQ(ret, 3);

  // deleting a non-empty bucket must fail
  ret = bclient->delete_bucket();
  ASSERT_EQ(ret, -1);

  ret = bclient->delete_object("bucket_operations/testfile");
  ASSERT_EQ(ret, 0);

  ret = bclient->delete_bucket();
  ASSERT_EQ(ret, 0);

  // the bucket is gone now
  ret = bclient->put_object("bucket_operations/testfile", &iov, 1);
  ASSERT_EQ(ret, -1);
}

void BasicAuthOssTest::list_objects() {
  std::vector<std::string> test_objects = {
      // they are in lexicographic order
      get_real_test_path("list-test/obj1.txt"),
      get_real_test_path("list-test/obj2.txt"),
      get_real_test_path("list-test/obj3.txt"),
      get_real_test_path("list-test/obj4.txt"),
      get_real_test_path("list-test/obj5.txt"),
      get_real_test_path("list-test/ocomprefix/obj6.txt")};
  auto com_prefix_key = get_real_test_path("list-test/ocomprefix/");

  char buf[3] = {3};
  iovec iov{buf, 3};
  auto crc64 = crc64ecma(buf, 3, 0);
  for (const auto& key : test_objects) {
    int ret = client->put_object(key, &iov, 1, &crc64);
    ASSERT_EQ(ret, 3);
  }

  struct ListObjectsInfo {
    estring key;
    estring etag;
    size_t size;
    time_t mtime;
    bool is_com_prefix;
    ListObjectsInfo(estring_view k, estring_view e, size_t s, time_t m,
                    bool is_com)
        : key(k), etag(e), size(s), mtime(m), is_com_prefix(is_com) {}
  };
  std::vector<ListObjectsInfo> listed_objects;
  auto list_callback = [&](const ListObjectsCBParameters& params) {
    listed_objects.emplace_back(params.key, params.etag, params.size,
                                params.mtime, params.is_com_prefix);
    return 0;
  };

  auto test_list_func = [&](auto list_fun) {
    listed_objects.clear();
    int ret =
        list_fun(get_real_test_path("list-test/"), list_callback, false, 2);
    ASSERT_EQ(ret, 0);
    ASSERT_EQ(listed_objects.size(), test_objects.size());

    for (size_t i = 0; i < listed_objects.size(); ++i) {
      EXPECT_EQ(listed_objects[i].key, test_objects[i]);
      EXPECT_FALSE(listed_objects[i].etag.empty());
      EXPECT_FALSE(listed_objects[i].is_com_prefix);
      EXPECT_EQ(listed_objects[i].size, 3);
      EXPECT_NE(listed_objects[i].mtime, 0);
    }

    listed_objects.clear();
    ret = list_fun(get_real_test_path("list-test/"), list_callback, true, 2);
    ASSERT_EQ(ret, 0);
    ASSERT_EQ(listed_objects.size(), test_objects.size());

    for (size_t i = 0; i < listed_objects.size() - 1; ++i) {
      EXPECT_EQ(listed_objects[i].key, test_objects[i]);
      EXPECT_FALSE(listed_objects[i].etag.empty());
      EXPECT_FALSE(listed_objects[i].is_com_prefix);
      EXPECT_EQ(listed_objects[i].size, 3);
      EXPECT_NE(listed_objects[i].mtime, 0);
    }

    EXPECT_TRUE(listed_objects.back().is_com_prefix);
    EXPECT_EQ(listed_objects.back().key, com_prefix_key);
  };

  test_list_func([&](std::string_view prefix, ListObjectsCallback cb,
                     bool delimiter, int max_keys) {
    ListObjectsParameters params;
    params.slash_delimiter = delimiter;
    params.max_keys = max_keys;
    params.ver = 2;
    return client->list_objects(prefix, cb, params);
  });
  test_list_func([&](std::string_view prefix, ListObjectsCallback cb,
                     bool delimiter, int max_keys) {
    ListObjectsParameters params;
    params.slash_delimiter = delimiter;
    params.max_keys = max_keys;
    params.ver = 1;
    return client->list_objects(prefix, cb, params);
  });

  auto test_one_shot = [&](auto list_fun) {
    listed_objects.clear();
    std::string marker;
    int ret = list_fun(get_real_test_path("list-test/"), list_callback, false,
                       2, &marker);
    ASSERT_EQ(ret, 0);
    ASSERT_EQ(listed_objects.size(), 2);

    ret = list_fun(get_real_test_path("list-test/"), list_callback, false, 2,
                   &marker);
    ASSERT_EQ(ret, 0);
    ASSERT_EQ(listed_objects.size(), 4);

    for (size_t i = 0; i < listed_objects.size(); ++i) {
      EXPECT_EQ(listed_objects[i].key, test_objects[i]);
    }
  };
  test_one_shot([&](std::string_view prefix, ListObjectsCallback cb,
                    bool delimiter, int max_keys, std::string* marker) {
    ListObjectsParameters params;
    params.slash_delimiter = delimiter;
    params.max_keys = max_keys;
    params.ver = 1;
    return client->list_objects(prefix, cb, params, marker);
  });
  test_one_shot([&](std::string_view prefix, ListObjectsCallback cb,
                    bool delimiter, int max_keys, std::string* marker) {
    ListObjectsParameters params;
    params.slash_delimiter = delimiter;
    params.max_keys = max_keys;
    params.ver = 2;
    return client->list_objects(prefix, cb, params, marker);
  });
}

void BasicAuthOssTest::put_and_get_meta() {
  auto path = get_real_test_path("object_meta/testfile.unknown_suffix");
  const size_t file_size = 1025;
  char buf[file_size] = {3};
  auto crc64 = crc64ecma(buf, file_size, 0);
  iovec iov{buf, file_size};
  int ret = client->put_object(path, &iov, 1, &crc64);
  ASSERT_EQ(ret, file_size) << "Failed to upload object for metadata test";
  crc64 += 1;
  ret = client->put_object(path, &iov, 1, &crc64);
  ASSERT_EQ(ret, -1) << "crc64 check did not work";

  // todo: add crc64 comparison
  ObjectHeaderMeta hmeta;
  ret = client->head_object(path, hmeta);
  ASSERT_EQ(ret, 0);
  EXPECT_TRUE(hmeta.has_etag());
  EXPECT_TRUE(hmeta.has_size());
  EXPECT_TRUE(hmeta.has_mtime());
  EXPECT_TRUE(hmeta.has_crc64());
  EXPECT_TRUE(hmeta.has_storage_class());
  EXPECT_TRUE(hmeta.has_type());
  EXPECT_EQ(hmeta.size, file_size);
  EXPECT_TRUE(!hmeta.etag.empty());
  EXPECT_NE(hmeta.mtime, 0);
  EXPECT_TRUE(hmeta.has_crc64());
  EXPECT_TRUE(!hmeta.storage_class.empty());
  EXPECT_TRUE(!hmeta.type.empty());

  ObjectMeta meta;
  ret = client->get_object_meta(path, meta);
  ASSERT_EQ(ret, 0);
  EXPECT_TRUE(meta.has_etag());
  EXPECT_TRUE(meta.has_size());
  EXPECT_TRUE(meta.has_mtime());
  EXPECT_EQ(meta.size, file_size);
  EXPECT_TRUE(!meta.etag.empty());
  EXPECT_EQ(meta.mtime, hmeta.mtime);

  ObjectHeaderMeta hmeta2;
  char buf2[2];
  iovec iov2{buf2, 2};
  ret = client->get_object_range(path, &iov2, 1, file_size - 1, &hmeta2);
  ASSERT_EQ(ret, 1);
  /// From testing, get obj range will return all the following fileds.
  EXPECT_EQ(hmeta2.flags, hmeta.flags);
  EXPECT_EQ(hmeta2.size, hmeta.size);
  EXPECT_EQ(hmeta2.crc64, hmeta.crc64);
  EXPECT_EQ(hmeta2.mtime, hmeta.mtime);
  EXPECT_EQ(hmeta2.storage_class, hmeta.storage_class);
  EXPECT_EQ(hmeta2.crc64, hmeta.crc64);
  EXPECT_EQ(hmeta2.etag, hmeta.etag);

  auto expected_crc64 = hmeta2.crc64;
  ret = client->put_object(path, &iov, 1, &expected_crc64);
  ASSERT_EQ(ret, file_size);
  expected_crc64 = hmeta2.crc64 + 1;
  ret = client->put_object(path, &iov, 1, &expected_crc64);
  ASSERT_EQ(ret, -1);
}

void BasicAuthOssTest::copy_and_rename() {
  auto src = get_real_test_path("copy_and_rename_object/src.mp3");
  auto dst = get_real_test_path("copy_and_rename_object/dst.mp4");

  iovec iov{nullptr, 0};
  int ret = client->put_object(src, &iov, 1);
  ASSERT_EQ(ret, 0);
  ret = client->copy_object(src, dst, false, true);
  ASSERT_EQ(ret, 0);
  ret = client->copy_object(src, dst, false, true);
  ASSERT_EQ(ret, -1);  // overwrite is not allowed

  auto dst2 = get_real_test_path("copy_and_rename_object/dst2.mp4");
  ObjectCopyOptions copy_opts;
  copy_opts.overwrite = true;
  copy_opts.set_mime = true;
  ret = client->copy_object(dst, dst2, copy_opts);
  ASSERT_EQ(ret, 0);
  EXPECT_TRUE(copy_opts.crc64.has_value());

  ret = client->rename_object(src, dst);
  ASSERT_EQ(ret, 0);
}

void BasicAuthOssTest::append_and_get() {
  auto path = get_real_test_path("append_and_get/testfile");

  char buf[2] = {'1', '2'};
  iovec iov{buf, 2};
  int ret = client->append_object(path, &iov, 1, 0);
  ASSERT_EQ(ret, 2);
  ret = client->append_object(path, &iov, 1, 2);
  ASSERT_EQ(ret, 2);

  char buf2[4];
  iovec iov2{buf2, 4};
  ret = client->get_object_range(path, &iov2, 1, 0);
  ASSERT_EQ(ret, 4);
  ASSERT_EQ(std::string(buf2, 4), "1212");
}

void BasicAuthOssTest::multipart() {
  auto path = get_real_test_path("multipart_upload/testfile");

  void* context = nullptr;
  int ret = client->init_multipart_upload(path, &context);
  ASSERT_EQ(ret, 0);
  const size_t buf_size = 1048577;
  uint64_t crc64 = 0;
  for (int i = 0; i < 5; i++) {
    char buf[buf_size] = {(char)i};
    crc64 = crc64ecma(buf, buf_size, crc64);
    iovec iov{buf, buf_size};

    auto part_crc64 = crc64ecma(buf, buf_size, 0);
    ret = client->upload_part(context, &iov, 1, i + 1, &part_crc64);
    ASSERT_EQ(ret, buf_size);
  }
  ret = client->complete_multipart_upload(context, &crc64);
  ASSERT_EQ(ret, 0);

  ObjectMeta meta;
  ret = client->get_object_meta(path, meta);
  ASSERT_EQ(ret, 0);
  ASSERT_EQ(meta.size, buf_size * 5);

  auto path4copy = get_real_test_path("multipart_upload/testfile_copy");
  auto ctx = client->init_multipart_upload(path4copy);
  if (!ctx) {
    ASSERT_TRUE(false);
  }
  for (int i = 0; i < 5; i++) {
    ObjectPartCopyOptions pc_opts;
    ret = ctx.copy(i * buf_size, buf_size, i + 1, path, pc_opts);
    ASSERT_EQ(ret, 0);
    EXPECT_TRUE(pc_opts.crc64.has_value());
  }
  ret = ctx.complete(nullptr);
  ASSERT_EQ(ret, 0);

  ObjectMeta meta_copyed;
  ret = client->get_object_meta(path4copy, meta_copyed);
  ASSERT_EQ(ret, 0);
  EXPECT_EQ(meta.size, meta_copyed.size);
  EXPECT_EQ(meta.etag, meta_copyed.etag);

  auto path4abort = get_real_test_path("multipart_upload/testfile_abort");
  ctx = client->init_multipart_upload(path4abort);
  if (!ctx) {
    ASSERT_TRUE(false);
  }
  for (int i = 0; i < 5; i++) {
    ret = ctx.copy(i * buf_size, buf_size, i + 1, path);
    ASSERT_EQ(ret, 0);
  }
  ret = ctx.abort();
  ASSERT_EQ(ret, 0);
}

void BasicAuthOssTest::symlink() {
  auto src = get_real_test_path("symlink/source");
  auto target = "symlink/target";

  int r = client->put_symlink(src, target);
  ASSERT_EQ(r, 0);

  std::string oss_target;
  r = client->get_symlink(src, oss_target);
  ASSERT_EQ(r, 0);

  EXPECT_EQ(oss_target, target);

  std::vector<std::string> objects;
  auto cb = [&](const ListObjectsCBParameters& cb) {
    objects.emplace_back(cb.key);
    if (cb.type == "Symlink") return 0;
    return -1;
  };
  int ret = client->list_objects(get_real_test_path("symlink/"), cb);
  EXPECT_EQ(ret, 0);
  ASSERT_EQ(objects.size(), 1);
  EXPECT_EQ(objects[0], src);
}

void BasicAuthOssTest::batch_get_objects() {
  int good_obj_cnt = 6, bad_obj_cnt = 3;
  std::vector<std::string> good_objs;
  std::vector<std::string> bad_objs;

  const size_t file_size = 1024;
  char test_data[file_size];
  for (size_t i = 0; i < file_size; i++) {
    test_data[i] = 'A' + (i % 26);
  }
  iovec iov{test_data, file_size};

  for (int i = 0; i < good_obj_cnt; i++) {
    auto src = get_real_test_path("batch_get_objects/good_testfile" +
                                  std::to_string(i));
    good_objs.push_back(src);

    auto crc64 = crc64ecma(test_data, file_size, 0);
    int ret = client->put_object(src, &iov, 1, &crc64);
    ASSERT_EQ(ret, (int)file_size) << "Failed to upload test object " << i;
  }

  for (int i = 0; i < bad_obj_cnt; i++) {
    auto src = get_real_test_path("batch_get_objects/bad_testfile" +
                                  std::to_string(i));
    bad_objs.push_back(src);
  }

  std::vector<GetObjectParameters> params_vec;
  std::vector<char*> bufs(good_objs.size());
  std::vector<struct iovec> iovs(good_objs.size());
  DEFER(for (auto buf : bufs) { delete buf; });

  for (size_t i = 0; i < good_objs.size(); i++) {
    auto buf_size = (i == 0) ? (file_size + 1) : (file_size - i);

    char* buffer = (char *)malloc(buf_size);
    bufs[i] = buffer;
    iovs[i] = {buffer, buf_size};

    GetObjectParameters params;
    params.offset = i;
    params.iov = &iovs[i];
    params.iovcnt = 1;
    params.object = good_objs[i];
    params_vec.push_back(params);
  }

  for (size_t i = 0; i < bad_objs.size(); i++) {
    GetObjectParameters params;
    params.object = bad_objs[i];
    params_vec.push_back(params);

    // no need to fill other information for bad objects
  }

  ObjectHeaderMeta hmeta;
  if (good_obj_cnt > 0) {
    params_vec[rand() % good_obj_cnt].meta = &hmeta;
  }

  std::random_device rd;
  std::mt19937 gen(rd());
  std::shuffle(params_vec.begin(), params_vec.end(), gen);

  int ret = client->batch_get_objects(params_vec);
  ASSERT_EQ(ret, good_obj_cnt);

  if (good_obj_cnt > 0) {
    EXPECT_EQ(hmeta.size, file_size);
    EXPECT_TRUE(!hmeta.etag.empty());
    EXPECT_NE(hmeta.mtime, 0);
    EXPECT_TRUE(hmeta.has_crc64());
    EXPECT_TRUE(!hmeta.storage_class.empty());
    EXPECT_TRUE(!hmeta.type.empty());
    LOG_INFO("etag ` mtime ` crc64 ` storage_class ` type `", hmeta.etag,
             hmeta.mtime, hmeta.crc64, hmeta.storage_class, hmeta.type);
  }

  for (auto& param : params_vec) {
    if (param.iov) {
      // good object 
      if (param.iov->iov_len > file_size) {
        ASSERT_EQ(param.result, file_size); // only valid data are returned
      } else {
        ASSERT_EQ(param.result, param.iov->iov_len);
      }
    }
  }

  for (size_t i = 0; i < good_objs.size(); i++) {
    bool data_correct = true;
    for (size_t j = i; j < file_size ; j++) {
      if (bufs[i][j-i] != (char)('A' + (j % 26))) {
        data_correct = false;
        LOG_INFO("Data mismatch for good object ` at offset ` ` `", i, j, (int)bufs[i][j], ('A' + (j % 26)));
        break;
      }
    }
    ASSERT_TRUE(data_correct) << "Data mismatch for good object " << i;
  }
}

void BasicAuthOssTest::get_object_ranges() {
  // range lists that OSS would not answer with one part per range are rejected
  // before anything reaches the network, so no object is needed for these
  char small[8];
  iovec small_iov{small, sizeof(small)};
  std::vector<GetRangeParameters> rejected = {{&small_iov, 1, 0}};
  ASSERT_EQ(client->get_object_ranges("unused", rejected), -1) << "single range";
  ASSERT_EQ(errno, EINVAL);
  rejected = {{&small_iov, 1, 0}, {&small_iov, 1, 4}};
  ASSERT_EQ(client->get_object_ranges("unused", rejected), -1) << "overlapping";
  ASSERT_EQ(errno, EINVAL);
  rejected = {{&small_iov, 1, 100}, {&small_iov, 1, 0}};
  ASSERT_EQ(client->get_object_ranges("unused", rejected), -1) << "descending";
  ASSERT_EQ(errno, EINVAL);
  rejected.assign(51, {&small_iov, 1, 0});  // one more than OSS accepts
  for (size_t i = 0; i < rejected.size(); i++) rejected[i].offset = i * 16;
  ASSERT_EQ(client->get_object_ranges("unused", rejected), -1) << "too many";
  ASSERT_EQ(errno, EINVAL);

  // large enough that a part outgrows the parser's framing buffer and spans
  // several reads of the body
  const size_t file_size = 1 << 20;
  std::vector<char> test_data(file_size);
  for (size_t i = 0; i < file_size; i++) test_data[i] = 'A' + (i % 26);

  auto path = get_real_test_path("get_object_ranges/testfile");
  iovec src{test_data.data(), file_size};
  auto crc64 = crc64ecma(test_data.data(), file_size, 0);
  ASSERT_EQ(client->put_object(path, &src, 1, &crc64), (ssize_t)file_size);

  // a single-range GET signs fewer x-oss-* headers than the multi-range one
  // below, and both have to survive the same signature cache
  char probe[16];
  ASSERT_EQ(client->get_object_range(path, probe, sizeof(probe), 0),
            (ssize_t)sizeof(probe));

  // ascending and non-overlapping, the middle range scattered over two buffers
  std::vector<char> b0(1000), b1(4096), b2(300000);
  iovec iov0{b0.data(), b0.size()};
  iovec iov1[2] = {{b1.data(), 2048}, {b1.data() + 2048, 2048}};
  iovec iov2{b2.data(), b2.size()};
  std::vector<GetRangeParameters> ranges = {
      {&iov0, 1, 0},
      {iov1, 2, 4096},
      {&iov2, 1, (off_t)(file_size - b2.size())}};

  ASSERT_EQ(client->get_object_ranges(path, ranges), 0);

  const std::vector<char>* bufs[] = {&b0, &b1, &b2};
  for (size_t i = 0; i < ranges.size(); i++) {
    ASSERT_EQ(ranges[i].result, (ssize_t)bufs[i]->size()) << "range " << i;
    ASSERT_EQ(memcmp(bufs[i]->data(), test_data.data() + ranges[i].offset,
                     bufs[i]->size()),
              0)
        << "range " << i;
  }

  // the parser consumed the body as far as the connection is concerned
  ASSERT_EQ(client->get_object_range(path, probe, sizeof(probe), 0),
            (ssize_t)sizeof(probe));

  // a range list reaching past the end of the object is not answered as
  // multipart at all, and is reported as a rejected range list
  std::vector<char> tail(64);
  iovec iov_tail{tail.data(), tail.size()};
  std::vector<GetRangeParameters> overshooting = {
      {&iov0, 1, 0}, {&iov_tail, 1, (off_t)(file_size - 32)}};
  ASSERT_EQ(client->get_object_ranges(path, overshooting), -1);
  ASSERT_EQ(errno, EINVAL);
}

void BasicAuthOssTest::upload_with_options() {
  // put_object
  auto path = get_real_test_path("upload_with_options/testfile");
  const size_t file_size = 1025;
  char buf[file_size] = {3};
  auto crc64 = crc64ecma(buf, file_size, 0);
  iovec iov{buf, file_size};

  std::string etag;
  ObjectUploadOptions opts{&crc64, &etag};
  int ret = client->put_object(path, &iov, 1, opts);
  ASSERT_EQ(ret, file_size) << "Failed to put object for upload test";

  uint64_t invalid_crc64 = 0xdeadbeef;
  ObjectUploadOptions opts_wrong_crc64{&invalid_crc64, &etag};
  ret = client->put_object(path, &iov, 1, opts_wrong_crc64);
  ASSERT_EQ(ret, -1) << "crc64 check did not work";

  ObjectMeta meta;
  ret = client->get_object_meta(path, meta);
  ASSERT_EQ(ret, 0);
  EXPECT_TRUE(meta.has_etag());
  EXPECT_EQ(meta.etag, etag);

  // append_object
  path = get_real_test_path("upload_with_options/testfile.append");

  ret = client->append_object(path, &iov, 1, 0, opts);
  ASSERT_EQ(ret, file_size) << "Failed to append object for upload test";

  ret = client->get_object_meta(path, meta);
  ASSERT_EQ(ret, 0);
  EXPECT_TRUE(meta.has_etag());
  EXPECT_EQ(meta.etag, etag);

  // multipart
  path = get_real_test_path("upload_with_options/testfile.multipart");
  void* context = nullptr;
  ret = client->init_multipart_upload(path, &context);
  ASSERT_EQ(ret, 0);

  ret = client->upload_part(context, &iov, 1, 1, opts);
  ASSERT_EQ(ret, file_size) << "Failed to upload object for upload test";

  ret = client->complete_multipart_upload(context, opts);
  ASSERT_EQ(ret, 0);

  ret = client->get_object_meta(path, meta);
  ASSERT_EQ(ret, 0);
  EXPECT_TRUE(meta.has_etag());
  EXPECT_EQ(meta.etag, etag);
}

struct FdWriterCtx {
  int fd;
  off_t base_offset;
  size_t length;
  // If true, fail on the first invocation (without a complete write) to trigger
  // do_http_call's retry; later invocations write the complete body. Used to
  // verify the writer is re-invoked from the beginning on a fresh socket.
  bool fail_first = false;
  int invocations = 0;
};

struct FdReaderCtx {
  int fd;
  off_t base_offset;
  // If true, read only a small portion on the first invocation and return short
  // (total < content_length) to trigger get_object_range's retry; later
  // invocations (a fresh GET) read the complete body.
  bool short_first = false;
  int invocations = 0;
};

// Reads the complete body from the stream and pwrites it to fd, looping until
// the stream ends. With short_first set, returns a partial read once to
// exercise the retry path.
static ssize_t fd_body_reader_cb(void* ctx_ptr, IStream* input) {
  auto* ctx = static_cast<FdReaderCtx*>(ctx_ptr);
  char buf[64 * 1024];
  ++ctx->invocations;
  if (ctx->short_first && ctx->invocations == 1) {
    // deliberately read too little to force a partial read
    ssize_t n = input->read(buf, 100);
    if (n <= 0) return n;
    if (::pwrite(ctx->fd, buf, n, ctx->base_offset) != n) return -1;
    return n;
  }
  ssize_t total = 0;
  while (true) {
    ssize_t n = input->read(buf, sizeof(buf));
    if (n < 0) return n;
    if (n == 0) break;
    if (::pwrite(ctx->fd, buf, n, ctx->base_offset + total) != n) return -1;
    total += n;
  }
  return total;
}

// Reads `length` bytes from fd and writes the complete body to the stream,
// looping until done. With fail_first set, fails once to exercise the retry
// path.
static ssize_t fd_body_writer_cb(void* ctx_ptr, IStream* output) {
  auto* ctx = static_cast<FdWriterCtx*>(ctx_ptr);
  ++ctx->invocations;
  if (ctx->fail_first && ctx->invocations == 1) return -1;
  char buf[64 * 1024];
  size_t total = 0;
  while (total < ctx->length) {
    size_t want = std::min(ctx->length - total, sizeof(buf));
    ssize_t n = ::pread(ctx->fd, buf, want, ctx->base_offset + total);
    if (n <= 0) return -1;
    if (output->write(buf, n) != n) return -1;
    total += n;
  }
  return (ssize_t)total;
}

void BasicAuthOssTest::fd_get_and_put() {
  auto path = get_real_test_path("fd_get_and_put/testfile");

  // Prepare a temp file with random data
  const size_t file_size = 1024 * 100 + 7;  // 100KB + 7 bytes
  std::vector<char> data(file_size);
  std::mt19937 rng(42);
  for (auto& c : data) c = static_cast<char>(rng() & 0xFF);

  char tmpfile[] = "/tmp/photon_oss_test_put_XXXXXX";
  int fd = ::mkstemp(tmpfile);
  ASSERT_GE(fd, 0);
  DEFER(::close(fd); ::unlink(tmpfile));
  ASSERT_EQ(::pwrite(fd, data.data(), file_size, 0), (ssize_t)file_size);

  // Upload using BodyWriter from fd
  FdWriterCtx wctx{fd, 0, file_size};
  BodyWriter writer{&wctx, &fd_body_writer_cb};
  ObjectUploadOptions opts;
  auto ret = client->put_object(path, file_size, writer, opts);
  ASSERT_EQ(ret, (ssize_t)file_size) << "put_object(BodyWriter) failed";

  // Download using BodyReader to fd
  char tmpfile_dl[] = "/tmp/photon_oss_test_get_XXXXXX";
  int fd_dl = ::mkstemp(tmpfile_dl);
  ASSERT_GE(fd_dl, 0);
  DEFER(::close(fd_dl); ::unlink(tmpfile_dl));
  ASSERT_EQ(::ftruncate(fd_dl, file_size), 0);

  FdReaderCtx rctx{fd_dl, 0};
  BodyReader reader{&rctx, &fd_body_reader_cb};
  ret = client->get_object_range(path, 0, file_size, reader);
  ASSERT_EQ(ret, (ssize_t)file_size) << "get_object_range(BodyReader) failed";

  std::vector<char> downloaded(file_size);
  ASSERT_EQ(::pread(fd_dl, downloaded.data(), file_size, 0), (ssize_t)file_size);
  ASSERT_EQ(data, downloaded);

  // Verify partial range download (offset=1024, count=512) to fd
  FdReaderCtx rctx_partial{fd_dl, 0};
  BodyReader reader_partial{&rctx_partial, &fd_body_reader_cb};
  ret = client->get_object_range(path, 1024, 512, reader_partial);
  ASSERT_EQ(ret, 512);
  char partial_buf[512];
  ASSERT_EQ(::pread(fd_dl, partial_buf, 512, 0), 512);
  ASSERT_EQ(memcmp(partial_buf, data.data() + 1024, 512), 0);

  // Also verify iov-based download still works
  std::vector<char> downloaded_iov(file_size);
  struct iovec iov = {downloaded_iov.data(), file_size};
  ret = client->get_object_range(path, &iov, 1, 0);
  ASSERT_EQ(ret, (ssize_t)file_size) << "get_object_range(iov) failed";
  ASSERT_EQ(data, downloaded_iov);
}

void BasicAuthOssTest::fd_multipart() {
  auto path = get_real_test_path("fd_multipart/testfile");

  // Prepare source file with 3 parts
  const size_t part_size = 1048576 + 13;  // >1MB per part (OSS minimum)
  const int num_parts = 3;
  const size_t total_size = part_size * num_parts;

  std::vector<char> data(total_size);
  std::mt19937 rng(123);
  for (auto& c : data) c = static_cast<char>(rng() & 0xFF);

  char tmpfile[] = "/tmp/photon_oss_test_mp_XXXXXX";
  int fd = ::mkstemp(tmpfile);
  ASSERT_GE(fd, 0);
  DEFER(::close(fd); ::unlink(tmpfile));
  ASSERT_EQ(::pwrite(fd, data.data(), total_size, 0), (ssize_t)total_size);

  // Multipart upload using BodyWriter from fd
  void* context = nullptr;
  int ret = client->init_multipart_upload(path, &context);
  ASSERT_EQ(ret, 0);

  for (int i = 0; i < num_parts; i++) {
    FdWriterCtx wctx{fd, (off_t)(i * part_size), part_size};
    BodyWriter writer{&wctx, &fd_body_writer_cb};
    ObjectUploadOptions opts;
    auto r = client->upload_part(context, part_size, i + 1, writer, opts);
    ASSERT_EQ(r, (ssize_t)part_size) << "upload_part(BodyWriter) failed on part " << (i + 1);
  }

  ret = client->complete_multipart_upload(context);
  ASSERT_EQ(ret, 0);

  // Download and verify
  std::vector<char> downloaded(total_size);
  struct iovec diov = {downloaded.data(), total_size};
  auto r = client->get_object_range(path, &diov, 1, 0);
  ASSERT_EQ(r, (ssize_t)total_size);
  ASSERT_EQ(data, downloaded);
}

void BasicAuthOssTest::retry_get_and_put() {
  auto path = get_real_test_path("retry_get_and_put/testfile");

  // Use a file larger than one read chunk so the reader's first (short) read
  // is strictly less than content_length.
  const size_t file_size = 1024 * 100 + 7;  // 100KB + 7 bytes
  std::vector<char> data(file_size);
  std::mt19937 rng(7);
  for (auto& c : data) c = static_cast<char>(rng() & 0xFF);

  char tmpfile[] = "/tmp/photon_oss_test_retry_XXXXXX";
  int fd = ::mkstemp(tmpfile);
  ASSERT_GE(fd, 0);
  DEFER(::close(fd); ::unlink(tmpfile));
  ASSERT_EQ(::pwrite(fd, data.data(), file_size, 0), (ssize_t)file_size);

  // put_object: writer fails on the first attempt -> do_http_call retries,
  // re-invoking the writer from the beginning on a fresh socket.
  FdWriterCtx wctx{fd, 0, file_size, /*fail_first=*/true};
  BodyWriter writer{&wctx, &fd_body_writer_cb};
  ObjectUploadOptions opts;
  auto ret = client->put_object(path, file_size, writer, opts);
  ASSERT_EQ(ret, (ssize_t)file_size) << "put_object with retry failed";
  ASSERT_GT(wctx.invocations, 1) << "do_http_call retry did not happen for put";

  // get_object_range: reader returns short on the first attempt -> the
  // `ret != content_length` check triggers a full retry (a fresh GET).
  char tmpfile_dl[] = "/tmp/photon_oss_test_retry_dl_XXXXXX";
  int fd_dl = ::mkstemp(tmpfile_dl);
  ASSERT_GE(fd_dl, 0);
  DEFER(::close(fd_dl); ::unlink(tmpfile_dl));
  ASSERT_EQ(::ftruncate(fd_dl, file_size), 0);

  FdReaderCtx rctx{fd_dl, 0, /*short_first=*/true};
  BodyReader reader{&rctx, &fd_body_reader_cb};
  ret = client->get_object_range(path, 0, file_size, reader);
  ASSERT_EQ(ret, (ssize_t)file_size) << "get_object_range with retry failed";
  ASSERT_GT(rctx.invocations, 1) << "get_object_range retry did not happen";

  std::vector<char> downloaded(file_size);
  ASSERT_EQ(::pread(fd_dl, downloaded.data(), file_size, 0), (ssize_t)file_size);
  ASSERT_EQ(data, downloaded) << "content mismatch after retry";
}

void CachedAuthOssTest::repeatedly_get() {
  std::vector<std::string> paths;
  const size_t file_size = 1025;
  char buf[file_size] = {2};
  iovec iov{buf, file_size};
  auto crc64 = crc64ecma(buf, file_size, 0);
  for (int i = 0; i < 10; i++) {
    auto path =
        get_real_test_path("rput_and_get/testfile.suffix" + std::to_string(i));
    int ret = client->put_object(path, &iov, 1, &crc64);
    ASSERT_EQ(ret, file_size) << "Failed to upload object for metadata test";
    paths.push_back(path);
  }

  for (size_t i = 0; i < 10; i++) {
    for (size_t j = 0; j < paths.size(); j++) {
      iov.iov_len = i + 1;
      auto ret = client->get_object_range(paths[j], &iov, 1, i, nullptr);
      EXPECT_EQ(ret, i + 1);
    }
  }

  client->set_credentials({"invalid creds"});
  LOG_INFO("creds invalidated");
  iov.iov_len = 1;
  auto ret = client->get_object_range(paths[0], &iov, 1, 0, nullptr);
  EXPECT_EQ(ret, -1);
  client->set_credentials({FLAGS_ak, FLAGS_sk});
  ret = client->get_object_range(paths[0], &iov, 1, 0, nullptr);
  EXPECT_EQ(ret, 1);
}

void BasicAuthOssTest::buf_put_and_get() {
  auto path = get_real_test_path("buf_put_and_get/testfile");
  const size_t file_size = 2048;
  char write_buf[file_size];
  for (size_t i = 0; i < file_size; i++) write_buf[i] = (char)(i & 0xff);

  // put_object with buf+size
  ObjectUploadOptions opts;
  auto ret = client->put_object(path, write_buf, file_size, opts);
  ASSERT_EQ(ret, (ssize_t)file_size);

  // get_object_range with buf+size
  char read_buf[file_size] = {};
  ret = client->get_object_range(path, read_buf, file_size, 0);
  ASSERT_EQ(ret, (ssize_t)file_size);
  ASSERT_EQ(memcmp(write_buf, read_buf, file_size), 0);

  // partial range read with buf+size
  char partial_buf[128] = {};
  ret = client->get_object_range(path, partial_buf, 128, 100);
  ASSERT_EQ(ret, 128);
  ASSERT_EQ(memcmp(write_buf + 100, partial_buf, 128), 0);
}

void BasicAuthOssTest::buf_multipart() {
  auto path = get_real_test_path("buf_multipart/testfile");
  const size_t part_size = 1048576;  // 1MB, minimum part size

  void* context = nullptr;
  int ret = client->init_multipart_upload(path, &context);
  ASSERT_EQ(ret, 0);

  std::vector<char> part_buf(part_size);
  ObjectUploadOptions opts;
  for (int i = 0; i < 3; i++) {
    memset(part_buf.data(), 'A' + i, part_size);
    auto r =
        client->upload_part(context, part_buf.data(), part_size, i + 1, opts);
    ASSERT_EQ(r, (ssize_t)part_size);
  }

  ret = client->complete_multipart_upload(context);
  ASSERT_EQ(ret, 0);

  // verify by reading back
  std::vector<char> verify_buf(part_size);
  std::vector<char> expected(part_size);
  for (int i = 0; i < 3; i++) {
    auto r = client->get_object_range(path, verify_buf.data(), part_size,
                                      (off_t)i * part_size);
    ASSERT_EQ(r, (ssize_t)part_size);
    memset(expected.data(), 'A' + i, part_size);
    ASSERT_EQ(memcmp(verify_buf.data(), expected.data(), part_size), 0);
  }
}

void BasicAuthOssTest::request_trace() {
  auto path = get_real_test_path("request_trace/testfile");
  char buf[4] = {1};
  iovec iov{buf, sizeof(buf)};

  // success: the last 2xx response is reflected in the trace
  RequestTrace trace;
  int ret = client->put_object(path, &iov, 1, nullptr, &trace);
  ASSERT_EQ(ret, (ssize_t)sizeof(buf));
  EXPECT_EQ(trace.http_code, 200);
  EXPECT_TRUE(!trace.request_id.empty());
  EXPECT_GE(trace.attempts, 1);
  EXPECT_FALSE(trace.throttled);
  EXPECT_GE(trace.server_time_ms, 1);

  ObjectHeaderMeta hmeta;
  ret = client->head_object(path, hmeta, &trace);
  ASSERT_EQ(ret, 0);
  EXPECT_EQ(trace.http_code, 200);
  EXPECT_TRUE(!trace.request_id.empty());

  // failure: a 404 still carries the server's response
  char buf2[4];
  iovec iov2{buf2, sizeof(buf2)};
  ret = client->get_object_range(get_real_test_path("request_trace/missing"),
                                 &iov2, 1, 0, nullptr, &trace);
  ASSERT_EQ(ret, -1);
  EXPECT_EQ(trace.http_code, 404);
  EXPECT_TRUE(!trace.request_id.empty());

  // reuse without reset(): `attempts` accumulates across calls
  auto attempts = trace.attempts;
  ret = client->head_object(path, hmeta, &trace);
  ASSERT_EQ(ret, 0);
  EXPECT_GE(trace.attempts, attempts + 1);

  // reuse after reset(): fields start over
  trace.reset();
  ret = client->head_object(path, hmeta, &trace);
  ASSERT_EQ(ret, 0);
  EXPECT_EQ(trace.attempts, 1);
  EXPECT_EQ(trace.http_code, 200);

  // a multi-page listing accumulates `attempts` across pages
  for (int i = 0; i < 2; i++) {
    ret = client->put_object(
        get_real_test_path("request_trace/page" + std::to_string(i)), &iov, 1);
    ASSERT_EQ(ret, (ssize_t)sizeof(buf));
  }
  trace.reset();
  std::vector<std::string> objects;
  auto cb = [&](const ListObjectsCBParameters& cb) {
    objects.emplace_back(std::string(cb.key));
    return 0;
  };
  ret = client->list_objects(bucket_prefix_, cb, {}, nullptr, &trace);
  ASSERT_EQ(ret, 0);
  EXPECT_GE(objects.size(), 3);
  EXPECT_GE(trace.attempts, 2);
}

TEST_F(BasicAuthOssTest, list_objects) { list_objects(); }
TEST_F(BasicAuthOssTest, bucket_operations) { bucket_operations(); }
TEST_F(BasicAuthOssTest, multipart) { multipart(); }
TEST_F(BasicAuthOssTest, append_and_get) { append_and_get(); }
TEST_F(BasicAuthOssTest, put_and_get_meta) { put_and_get_meta(); }
TEST_F(BasicAuthOssTest, copy_and_rename) { copy_and_rename(); }
TEST_F(BasicAuthOssTest, symlink) { symlink(); }
TEST_F(BasicAuthOssTest, batch_get_objects) { batch_get_objects(); }
TEST_F(BasicAuthOssTest, get_object_ranges) { get_object_ranges(); }
TEST_F(BasicAuthOssTest, request_trace) { request_trace(); }

TEST_F(BasicAuthOssTest, upload_with_options) { upload_with_options(); }
TEST_F(BasicAuthOssTest, fd_get_and_put) { fd_get_and_put(); }
TEST_F(BasicAuthOssTest, fd_multipart) { fd_multipart(); }
TEST_F(BasicAuthOssTest, retry_get_and_put) { retry_get_and_put(); }
TEST_F(BasicAuthOssTest, buf_put_and_get) { buf_put_and_get(); }
TEST_F(BasicAuthOssTest, buf_multipart) { buf_multipart(); }
TEST_F(CachedAuthOssTest, listobjects) { list_objects(); }
TEST_F(CachedAuthOssTest, multipart) { multipart(); }
TEST_F(CachedAuthOssTest, append_and_get) { append_and_get(); }
TEST_F(CachedAuthOssTest, put_and_get_meta) { put_and_get_meta(); }
TEST_F(CachedAuthOssTest, copy_and_rename) { copy_and_rename(); }
TEST_F(CachedAuthOssTest, repeatedly_get) { repeatedly_get(); }
TEST_F(CachedAuthOssTest, symlink) { symlink(); }
TEST_F(CachedAuthOssTest, batch_get_objects) { batch_get_objects(); }
TEST_F(CachedAuthOssTest, get_object_ranges) { get_object_ranges(); }

TEST_F(CachedAuthOssTest, upload_with_options) { upload_with_options(); }
TEST_F(CustomCachedAuthOssTest, repeatedly_get) { repeatedly_get(); }

int main(int argc, char* argv[]) {
  ::testing::InitGoogleTest(&argc, argv);
  gflags::ParseCommandLineFlags(&argc, &argv, true);

  if (FLAGS_ak.empty() || FLAGS_sk.empty() || FLAGS_endpoint.empty() ||
      FLAGS_bucket.empty()) {
    std::cerr << "Error: All parameters (ak, sk, endpoint, bucket) are "
                 "required! region is optional."
              << std::endl;
    std::cerr
        << "Usage: " << argv[0]
        << " --ak=<access_key_id> --sk=<access_key_secret> "
        << "--endpoint=<endpoint> --bucket=<bucket_name> --region=<region>"
        << std::endl;
    gflags::ShowUsageWithFlags(argv[0]);
    return 1;
  }
  photon::init(photon::INIT_EVENT_DEFAULT, photon::INIT_IO_NONE);
  DEFER(photon::fini());

  return RUN_ALL_TESTS();
}
