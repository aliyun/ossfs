add_executable(test-ecosystem test.cpp test_simple_dom.cpp test_redis.cpp test_oss_custom_headers.cpp)
target_link_libraries(test-ecosystem PRIVATE photon_shared)
add_test(NAME test-ecosystem COMMAND $<TARGET_FILE:test-ecosystem>)

add_executable(test-oss-resolve-ip test_oss_resolve_ip.cpp)
target_link_libraries(test-oss-resolve-ip PRIVATE photon_shared)
add_test(NAME test-oss-resolve-ip COMMAND $<TARGET_FILE:test-oss-resolve-ip>)

#add_executable(test-oss test_oss.cpp)
#target_link_libraries(test-oss PRIVATE photon_shared)
#add_test(NAME test-oss COMMAND $<TARGET_FILE:test-oss>)
