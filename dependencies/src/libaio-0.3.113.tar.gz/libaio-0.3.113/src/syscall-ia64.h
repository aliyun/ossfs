#define __NR_io_setup		1238
#define __NR_io_destroy		1239
#define __NR_io_getevents	1240
#define __NR_io_submit		1241
#define __NR_io_cancel		1242
