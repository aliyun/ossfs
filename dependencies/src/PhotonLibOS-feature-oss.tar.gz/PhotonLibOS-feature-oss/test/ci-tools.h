#pragma once

namespace photon {

bool is_using_default_engine();

void set_cpu_affinity(int i);

}
