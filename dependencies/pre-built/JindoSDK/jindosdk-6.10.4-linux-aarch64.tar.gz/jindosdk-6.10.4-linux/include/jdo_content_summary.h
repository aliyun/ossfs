#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoContentSummary_t jdo_createContentSummary();

JDO_EXPORT void jdo_freeContentSummary(JdoContentSummary_t contentSummary);

JDO_EXPORT int64_t jdo_getContentSummaryFileSize(JdoContentSummary_t contentSummary);

JDO_EXPORT int64_t jdo_getContentSummaryFileCount(JdoContentSummary_t contentSummary);

JDO_EXPORT int64_t jdo_getContentSummaryDirectoryCount(JdoContentSummary_t contentSummary);

#if defined (__cplusplus)
}
#endif
