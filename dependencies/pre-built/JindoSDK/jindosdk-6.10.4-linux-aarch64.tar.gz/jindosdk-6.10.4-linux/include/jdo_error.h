#pragma once

/**
 *     |------------|-----------------------|--------------------------|
 *     |   1xxx     |  (JDO) CLIENT ERROR   |--------------------------|
 *     |   2xxx     |  (JDO) NETWORK ERROR  |--------------------------|
 *     |   3xxx     |  (JDO) RESOURCE ERROR |--------------------------|
 *     |   4xxx     |  (JDO) SYSTEM ERROR   |--------------------------|
 *     |   5xxx     |  (JDO) SECURITY ERROR |--------------------------|
 *     |   6xxx     |  (JDO) OBJECT HTTP ERROR |-----------------------|
 *     |------------|-----------------------|--------------------------|
 */

/** CLIENT ERROR(Unretriable) **/
#define JDO_CLIENT_ERROR                         1000
#define JDO_CLIENT_ILLEGAL_CONF_ERROR            1001
#define JDO_CLIENT_ILLEGAL_REQUEST_ERROR         1002
#define JDO_CLIENT_NO_SPACE_RESOURCE_ERROR       1003
#define JDO_CLIENT_NO_MEM_RESOURCE_ERROR         1004
#define JDO_CLIENT_CHECKSUM_ERROR                1005
#define JDO_JNI_OBJ_ALLOCATION_ERROR             1006
#define JDO_CACHESET_NOT_AVAILABLE_ERROR         1007
#define JDO_CONFIG_OPTION_ERROR                  1008
#define JDO_CLIENT_NO_ENOUGHT_RESERVE_MEM_ERROR  1009

/** NETWORK ERROR(Retriable) **/
#define JDO_SERVER_ERROR                         2000
#define JDO_SERVER_UNAVAILABLE_ERROR             2001
#define JDO_SERVER_TIMEOUT_ERROR                 2002
#define JDO_SERVER_NO_IN_SERVICE_ERROR           2003

/** SERVER RESOURCE ERROR(Unretriable) **/
#define JDO_RESOURCE_ERROR                       3000
#define JDO_FILE_NOT_FOUND_ERROR                 3001
#define JDO_FILE_SIZE_EXCEEDED_ERROR             3002
#define JDO_FILE_NAME_EXCEEDED_ERROR             3003
#define JDO_QUOTA_EXCEEDED_ERROR                 3004
#define JDO_IO_ERROR                             3005
#define JDO_SERVER_INTERNAL_ERROR                3006
#define JDO_CORRUPT_DATA_ERROR                   3007
#define JDO_NO_SERVER_ERROR                      3008
#define JDO_SERVER_RESPONSE_TOO_LARGE_ERROR      3009

/** SYSTEM LOGIC ERROR(Unretriable) **/
#define JDO_SYSTEM_LOGIC_ERROR                   4000
#define JDO_NOT_SUPPORTED_ERROR                  4001

// operation logic error
#define JDO_RENAME_DST_UNDER_SRC_ERROR           4101
#define JDO_RENAME_DST_PARENT_NOT_FOUND_ERROR    4102
#define JDO_RENAME_DST_PARENT_FILE_ERROR         4103
#define JDO_RENAME_SRC_NOT_FOUND_ERROR           4104
#define JDO_RENAME_DST_EXIST_AS_FILE_ERROR       4105
#define JDO_RENAME_SRC_EQ_DST_AS_DIRECTORY_ERROR 4106
#define JDO_RENAME_SRC_EQ_DST_AS_FILE_ERROR      4107
#define JDO_DELETE_NOT_ALLOW_ERROR               4108
#define JDO_DELETE_DIRECTORY_NOT_EMPTY_ERROR     4109
#define JDO_PARENT_NOT_DIRECTORY_ERROR           4110
#define JDO_FILE_ALREADY_EXISTS_ERROR            4111
#define JDO_INVALID_PATH_ERROR                   4112
#define JDO_TIERED_OP_NOT_ALLOWED_ERROR          4113
#define JDO_RENAME_DST_EXIST_ERROR               4114
#define JDO_LOCAL_WRITE_ERROR                    4115
#define JDO_LOCAL_READ_ERROR                     4116
#define JDO_READ_TASK_TIMEOUT_ERROR              4117
#define JDO_WRITE_TASK_TIMEOUT_ERROR             4118
#define JDO_FILE_TYPE_IS_DIRECTORY_ERROR         4119
#define JDO_INVALID_ARGUMENT_ERROR               4120
#define JDO_NO_PERMISSION_ERROR                  4121
#define JDO_LEASE_EXPIRED_ERROR                  4122
#define JDO_SAFE_MODE_ERROR                      4123
#define JDO_PATH_NOT_EMPTY_DIRECTORY_ERROR       4124
#define JDO_SNAPSHOT_ERROR                       4125
#define JDO_EOF_ERROR                            4126
#define JDO_NOT_DLS_BUCKET_ERROR                 4127
#define JDO_CONFLICT_LOCK_ERROR                  4128
#define JDO_FILE_ALREADY_BEING_CREATED_ERROR     4129
#define JDO_STANDBY_ERROR                        4130
#define JDO_RENAME_ACROSS_STORES_ERROR           4131
#define JDO_CONCAT_ACROSS_STORES_ERROR           4132
#define JDO_UNRESOLVED_LINK_ERROR                4133
#define JDO_SYMLINK_LOOP_ERROR                   4134
#define JDO_SYMLINK_ACROSS_STORES_ERROR          4135

// xattr error
#define JDO_XATTR_ERROR                          4200
#define JDO_XATTR_NOT_EXIST_ERROR                4201
#define JDO_XATTR_SET_ERROR                      4202

// atomic rename
#define JDO_RENAME_LOCKED_BY_OTHERS_ERROR        4300
#define JDO_RENAME_OTS_OP_ERROR                  4301
#define JDO_RENAME_OTS_CONDITIONAL_UPDATE_ERROR  4302
#define JDO_RENAME_OTS_OBJECT_NOT_EXIST_ERROR    4303
#define JDO_RENAME_OTS_AUTH_FAILED_ERROR         4304
#define JDO_RENAME_OTS_SERVER_BUSY_ERROR         4305

/** SECURITY ERROR **/
#define JDO_SECURITY_ERROR                       5000
#define JDO_AUTHENTICATION_FAILED_ERROR          5001
#define JDO_ACCESS_CONTROL_ERROR                 5002
#define JDO_ACL_DENY_ERROR                       5003

// SASL
#define JDO_SASL_CLIENT_ERROR                    5101
#define JDO_SASL_SERVER_ERROR                    5102
#define JDO_KERBEROS_ERROR                       5103

// CRYPTO
#define JDO_CRYPTO_POLICY_ALREADY_EXIST_ERROR    5201
#define JDO_CRYPTO_POLICY_DIR_NOT_EMPTY_ERROR    5202
#define JDO_CRYPTO_KEY_NOT_EXIST_ERROR           5203
#define JDO_ENCRYPTED_KEY_ERROR                  5204
#define JDO_CRYPTO_POLICY_DISABLED_ERROR         5205

// MOUNT
#define JDO_CONFLICT_MOUNT_ERROR                 5301
#define JDO_NO_SUCH_MOUNT_ERROR                  5302

// ACCESS POLICY
#define JDO_ROOT_POLICY_ALREADY_EXIST_ERROR      5401
#define JDO_ROOT_POLICY_NOT_EXIST_ERROR          5402
#define JDO_TOO_MANY_ACCESS_POLICIES_ERROR       5403

// OBJECT HTTP ERROR
#define JDO_REST_HTTP_203_ERROR 6203
#define JDO_REST_HTTP_400_ERROR 6400
#define JDO_REST_HTTP_403_ERROR 6403
#define JDO_REST_HTTP_404_ERROR 6404
#define JDO_REST_HTTP_405_ERROR 6405
#define JDO_REST_HTTP_409_ERROR 6409
#define JDO_REST_HTTP_411_ERROR 6411
#define JDO_REST_HTTP_412_ERROR 6412
#define JDO_REST_HTTP_416_ERROR 6416
#define JDO_REST_HTTP_424_ERROR 6424
#define JDO_REST_HTTP_500_ERROR 6500
#define JDO_REST_HTTP_502_ERROR 6502
#define JDO_REST_HTTP_503_ERROR 6503
