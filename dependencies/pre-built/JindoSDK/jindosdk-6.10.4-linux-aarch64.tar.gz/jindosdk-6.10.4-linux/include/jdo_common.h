#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h>

#define JDO_EXPORT __attribute__((visibility("default")))

#if defined (__cplusplus)
extern "C" {
#endif

typedef void* JdoStore_t;
typedef void* JdoIOContext_t;
typedef void* JdoHandleCtx_t;
typedef void* JdoOptions_t;
typedef void* JdoLoginUser_t;
typedef void* JdoOperationCall_t;
typedef void* JdoAuthCredentialsProviderOptions_t;

#if defined (__cplusplus)
}
#endif
