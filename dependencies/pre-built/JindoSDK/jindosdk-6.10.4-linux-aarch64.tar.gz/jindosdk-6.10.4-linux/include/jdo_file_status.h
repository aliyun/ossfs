#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoFileStatus_t jdo_createFileStatus();

JDO_EXPORT void jdo_freeFileStatus(JdoFileStatus_t fileStatus);

JDO_EXPORT const char* jdo_getFileStatusPath(JdoFileStatus_t fileStatus);

JDO_EXPORT const char* jdo_getFileStatusUser(JdoFileStatus_t fileStatus);

JDO_EXPORT const char* jdo_getFileStatusGroup(JdoFileStatus_t fileStatus);

JDO_EXPORT int8_t jdo_getFileStatusType(JdoFileStatus_t fileStatus);

JDO_EXPORT int16_t jdo_getFileStatusPerm(JdoFileStatus_t fileStatus);

JDO_EXPORT int64_t jdo_getFileStatusSize(JdoFileStatus_t fileStatus);

JDO_EXPORT int64_t jdo_getFileStatusMtime(JdoFileStatus_t fileStatus);

JDO_EXPORT int64_t jdo_getFileStatusAtime(JdoFileStatus_t fileStatus);

JDO_EXPORT const char* jdo_getFileStatusEtag(JdoFileStatus_t fileStatus);

JDO_EXPORT const char* jdo_getFileStatusVersionId(JdoFileStatus_t fileStatus);

JDO_EXPORT int64_t jdo_getFileStatusFileIdInt64(JdoFileStatus_t fileStatus);

#if defined (__cplusplus)
}
#endif
