#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT void jdo_freeCopyObjectResult(JdoCopyObjectResult_t result);

#if defined (__cplusplus)
}
#endif
