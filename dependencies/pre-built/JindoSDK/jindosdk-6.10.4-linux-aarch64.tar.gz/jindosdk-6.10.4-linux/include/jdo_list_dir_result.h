#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoListDirResult_t jdo_createListDirResult();

JDO_EXPORT void jdo_freeListDirResult(JdoListDirResult_t listDirResult);

JDO_EXPORT int64_t jdo_getListDirResultSize(JdoListDirResult_t listDirResult);

JDO_EXPORT bool jdo_isListDirResultTruncated(JdoListDirResult_t listDirResult);

JDO_EXPORT const char* jdo_getListDirResultNextMarker(JdoListDirResult_t listDirResult);

JDO_EXPORT JdoFileStatus_t jdo_getListDirFileStatus(JdoListDirResult_t listDirResult, size_t index);

#if defined (__cplusplus)
}
#endif
