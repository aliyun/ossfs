#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT void jdo_freeObjectSummary(JdoObjectSummary_t result);

JDO_EXPORT const char* jdo_getObjectSummaryKey(JdoObjectSummary_t result);

JDO_EXPORT const char* jdo_getObjectSummaryETag(JdoObjectSummary_t result);

JDO_EXPORT const char* jdo_getObjectSummaryStorageClass(JdoObjectSummary_t result);

JDO_EXPORT int64_t jdo_getObjectSummarySize(JdoObjectSummary_t result);

JDO_EXPORT int64_t jdo_getObjectSummaryMtime(JdoObjectSummary_t result);

JDO_EXPORT const char* jdo_getObjectSummaryVersionId(JdoObjectSummary_t result);

#if defined (__cplusplus)
}
#endif
