#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoLoginUser_t jdo_createLoginUser(const char* name);

JDO_EXPORT void jdo_freeLoginUser(JdoLoginUser_t loginUser);

#if defined (__cplusplus)
}
#endif
