#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT void jdo_freeFileChecksum(JdoFileChecksum_t fileChecksum);

JDO_EXPORT int jdo_getFileChecksumMode(JdoFileChecksum_t fileChecksum);

JDO_EXPORT const char* jdo_getFileChecksumToString(JdoFileChecksum_t fileChecksum);

#if defined (__cplusplus)
}
#endif
