#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoFileBuffers_t jdo_createFileBuffers();

JDO_EXPORT void jdo_freeFileBuffers(JdoFileBuffers_t fileBuffers);

JDO_EXPORT int64_t jdo_getFileBuffersSize(JdoFileBuffers_t fileBuffers);

JDO_EXPORT void jdo_appendFileBuffer(JdoFileBuffers_t fileBuffers, char* buffer);

JDO_EXPORT char* jdo_getFileBuffersIterator(JdoFileBuffers_t fileBuffers, size_t index);

#if defined (__cplusplus)
}
#endif
