#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

typedef void (*JdoBoolCallback)(JdoHandleCtx_t ctx, bool, void*);
typedef void (*JdoInt64Callback)(JdoHandleCtx_t ctx, int64_t, void*);
typedef void (*JdoStringCallback)(JdoHandleCtx_t ctx, char*, void*);
typedef void (*JdoFileStatusCallback)(JdoHandleCtx_t ctx, JdoFileStatus_t, void*);
typedef void (*JdoListDirResultCallback)(JdoHandleCtx_t ctx, JdoListDirResult_t, void*);
typedef void (*JdoContentSummaryCallback)(JdoHandleCtx_t ctx, JdoContentSummary_t, void*);
typedef void (*JdoLockInfoCallback)(JdoHandleCtx_t ctx, JdoLockInfo_t, void*);
typedef void (*JdoXAttrListCallback)(JdoHandleCtx_t ctx, JdoXAttrList_t, void*);
typedef void (*JdoAclStatusCallback)(JdoHandleCtx_t ctx, JdoAclStatus_t, void*);
typedef void (*JdoFileChecksumCallback)(JdoHandleCtx_t ctx, JdoFileChecksum_t, void*);
typedef void (*JdoServerDefaultsCallback)(JdoHandleCtx_t ctx, JdoServerDefaults_t, void*);
typedef void (*JdoSnapshotDiffReportCallback)(JdoHandleCtx_t ctx, JdoSnapshotDiffReport_t, void*);
typedef void (*JdoGetListingCorruptFileBlocksCallback)(JdoHandleCtx_t ctx, JdoGetListingCorruptFileBlocksResult_t, void*);
typedef void (*JdoIOContextCallback)(JdoHandleCtx_t ctx, JdoIOContext_t, void*);
typedef void (*JdoPutObjectCallback)(JdoHandleCtx_t ctx, JdoPutObjectResult_t, void*);
typedef void (*JdoInitiateMultipartUploadResultCallback)(JdoHandleCtx_t ctx, JdoInitiateMultipartUploadResult_t, void*);
typedef void (*JdoUploadPartCallback)(JdoHandleCtx_t ctx, JdoObjectPartInfo_t, void*);
typedef void (*JdoCompleteMultipartUploadCallback)(JdoHandleCtx_t ctx, JdoCompleteMultipartUploadResult_t, void*);
typedef void (*JdoAbortMultipartUploadCallback)(JdoHandleCtx_t ctx, bool, void*);
typedef void (*JdoGetObjectCallback)(JdoHandleCtx_t ctx, int64_t, void*);
typedef void (*JdoGetObjectWithMetaCallback)(JdoHandleCtx_t ctx, JdoGetObjectResult_t, void*);
typedef void (*JdoGetObjectMetaCallback)(JdoHandleCtx_t ctx, JdoGetObjectMetaResult_t, void*);
typedef void (*JdoListObjectsCallback)(JdoHandleCtx_t ctx, JdoListObjectsResult_t, void*);
typedef void (*JdoDeleteObjectCallback)(JdoHandleCtx_t ctx, JdoDeleteObjectResult_t, void*);
typedef void (*JdoCopyObjectCallback)(JdoHandleCtx_t ctx, JdoCopyObjectResult_t, void*);

JDO_EXPORT JdoOptions_t jdo_createOptions();

JDO_EXPORT void jdo_freeOptions(JdoOptions_t options);

JDO_EXPORT void jdo_setOption(JdoOptions_t options, const char* key, const char* val);

JDO_EXPORT const char* jdo_getOption(JdoOptions_t options, const char* key, const char* def);

JDO_EXPORT void jdo_setBoolCallback(JdoOptions_t options, JdoBoolCallback callback);

JDO_EXPORT JdoBoolCallback jdo_getBoolCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setInt64Callback(JdoOptions_t options, JdoInt64Callback callback);

JDO_EXPORT JdoInt64Callback jdo_getInt64Callback(JdoOptions_t options);

JDO_EXPORT void jdo_setStringCallback(JdoOptions_t options, JdoStringCallback callback);

JDO_EXPORT JdoStringCallback jdo_getStringCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setFileStatusCallback(JdoOptions_t options, JdoFileStatusCallback callback);

JDO_EXPORT JdoFileStatusCallback jdo_getFileStatusCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setListDirResultCallback(JdoOptions_t options, JdoListDirResultCallback callback);

JDO_EXPORT JdoListDirResultCallback jdo_getListDirResultCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setContentSummaryCallback(JdoOptions_t options, JdoContentSummaryCallback callback);

JDO_EXPORT JdoContentSummaryCallback jdo_getContentSummaryCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setLockInfoCallback(JdoOptions_t options, JdoLockInfoCallback callback);

JDO_EXPORT JdoLockInfoCallback jdo_getLockInfoCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setXAttrListCallback(JdoOptions_t options, JdoXAttrListCallback callback);

JDO_EXPORT JdoXAttrListCallback jdo_getXAttrListCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setAclStatusCallback(JdoOptions_t options, JdoAclStatusCallback callback);

JDO_EXPORT JdoAclStatusCallback jdo_getAclStatusCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setFileChecksumCallback(JdoOptions_t options, JdoFileChecksumCallback callback);

JDO_EXPORT JdoFileChecksumCallback jdo_getFileChecksumCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setSeverDefaultsCallback(JdoOptions_t options, JdoServerDefaultsCallback callback);

JDO_EXPORT JdoServerDefaultsCallback jdo_getServerDefaultsCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setSnapshotDiffReportCallback(JdoOptions_t options, JdoSnapshotDiffReportCallback callback);

JDO_EXPORT JdoSnapshotDiffReportCallback jdo_getSnapshotDiffReportCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setGetListingCorruptFileBlocksCallback(JdoOptions_t options, JdoGetListingCorruptFileBlocksCallback callback);

JDO_EXPORT JdoGetListingCorruptFileBlocksCallback jdo_getGetListingCorruptFileBlocksCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setIOContextCallback(JdoOptions_t options, JdoIOContextCallback callback);

JDO_EXPORT JdoIOContextCallback jdo_getIOContextCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setPutObjectCallback(JdoOptions_t options, JdoPutObjectCallback callback);
JDO_EXPORT void jdo_setInitiateMultipartUploadResultCallback(JdoOptions_t options, JdoInitiateMultipartUploadResultCallback callback);
JDO_EXPORT void jdo_setUploadPartCallback(JdoOptions_t options, JdoUploadPartCallback callback);
JDO_EXPORT void jdo_setCompleteMultipartUploadCallback(JdoOptions_t options, JdoCompleteMultipartUploadCallback callback);
JDO_EXPORT void jdo_setAbortMultipartUploadCallback(JdoOptions_t options, JdoAbortMultipartUploadCallback callback);
JDO_EXPORT void jdo_setGetObjectCallback(JdoOptions_t options, JdoGetObjectCallback callback);

JDO_EXPORT JdoPutObjectCallback jdo_getPutObjectCallback(JdoOptions_t options);

JDO_EXPORT JdoInitiateMultipartUploadResultCallback jdo_getInitiateMultipartUploadResultCallback(JdoOptions_t options);

JDO_EXPORT JdoUploadPartCallback jdo_getUploadPartCallback(JdoOptions_t options);

JDO_EXPORT JdoCompleteMultipartUploadCallback jdo_getCompleteMultipartUploadCallback(JdoOptions_t options);

JDO_EXPORT JdoAbortMultipartUploadCallback jdo_getAbortMultipartUploadCallback(JdoOptions_t options);

JDO_EXPORT JdoGetObjectCallback jdo_getGetObjectCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setGetObjectWithMetaCallback(JdoOptions_t options, JdoGetObjectWithMetaCallback callback);

JDO_EXPORT JdoGetObjectWithMetaCallback jdo_getGetObjectWithMetaCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setGetObjectMetaCallback(JdoOptions_t options, JdoGetObjectMetaCallback callback);

JDO_EXPORT JdoGetObjectMetaCallback jdo_getGetObjectMetaCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setListObjectsCallback(JdoOptions_t options, JdoListObjectsCallback callback);

JDO_EXPORT JdoListObjectsCallback jdo_getListObjectsCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setDeleteObjectCallback(JdoOptions_t options, JdoDeleteObjectCallback callback);

JDO_EXPORT JdoGetObjectMetaCallback jdo_getDeleteObjectCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setCopyObjectCallback(JdoOptions_t options, JdoCopyObjectCallback callback);

JDO_EXPORT JdoCopyObjectCallback jdo_getCopyObjectCallback(JdoOptions_t options);

JDO_EXPORT void jdo_setCallbackContext(JdoOptions_t options, void* userdata);

JDO_EXPORT void* jdo_getCallbackContext(JdoOptions_t options);

#if defined (__cplusplus)
}
#endif
