#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoAclEntry_t jdo_createAclEntry();

JDO_EXPORT void jdo_freeAclEntry(JdoAclEntry_t aclEntry);

JDO_EXPORT void jdo_setAclEntryType(JdoAclEntry_t aclEntry, int type);

JDO_EXPORT int jdo_getAclEntryType(JdoAclEntry_t aclEntry);

JDO_EXPORT void jdo_setAclEntryPermission(JdoAclEntry_t aclEntry, int perm);

JDO_EXPORT int jdo_getAclEntryPermission(JdoAclEntry_t aclEntry);

JDO_EXPORT void jdo_setAclEntryScope(JdoAclEntry_t aclEntry, int scope);

JDO_EXPORT int jdo_getAclEntryScope(JdoAclEntry_t aclEntry);

JDO_EXPORT void jdo_setAclEntryName(JdoLockInfo_t lockInfo, const char* name);

JDO_EXPORT char* jdo_getAclEntryName(JdoLockInfo_t lockInfo);


#if defined (__cplusplus)
}
#endif
