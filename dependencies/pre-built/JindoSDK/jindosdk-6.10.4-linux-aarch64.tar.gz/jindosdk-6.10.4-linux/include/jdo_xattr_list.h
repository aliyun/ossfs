#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoXAttrList_t jdo_createXAttrList();

JDO_EXPORT void jdo_freeXAttrList(JdoXAttrList_t xAttr);

JDO_EXPORT int64_t jdo_getXAttrListSize(JdoXAttrList_t xAttrList);

JDO_EXPORT void jdo_appendXAttrList(JdoXAttrList_t xAttrList, JdoXAttr_t xAttr);

JDO_EXPORT JdoXAttr_t jdo_getXAttrsListIterator(JdoXAttrList_t xAttrList, size_t index);


#if defined (__cplusplus)
}
#endif
