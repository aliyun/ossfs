#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT void jdo_freeGetObjectResult(JdoGetObjectResult_t result);

JDO_EXPORT int64_t jdo_getObjectSize(JdoGetObjectResult_t result);

JDO_EXPORT int64_t jdo_getObjectMtime(JdoGetObjectResult_t result);

JDO_EXPORT const char* jdo_getObjectETag(JdoGetObjectResult_t result);

JDO_EXPORT const char* jdo_getObjectVersionId(JdoGetObjectResult_t result);

JDO_EXPORT const char* jdo_getObjectChecksumCrc64(JdoGetObjectResult_t result);

#if defined (__cplusplus)
}
#endif
