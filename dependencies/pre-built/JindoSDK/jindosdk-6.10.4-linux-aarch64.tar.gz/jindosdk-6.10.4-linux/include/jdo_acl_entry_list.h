#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoAclEntryList_t jdo_createAclEntryList();

JDO_EXPORT void jdo_freeAclEntryList(JdoAclEntryList_t aclEntryList);

JDO_EXPORT int64_t jdo_getAclEntryListSize(JdoAclEntryList_t aclEntryList);

JDO_EXPORT void jdo_appendAclEntryList(JdoAclEntryList_t aclEntryList, JdoAclEntry_t aclEntry);

JDO_EXPORT JdoAclEntry_t jdo_getAclEntrysListIterator(JdoAclEntryList_t aclEntryList, size_t index);


#if defined (__cplusplus)
}
#endif
