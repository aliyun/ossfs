#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoInitiateMultipartUploadResult_t jdo_createInitiateMultipartUploadResult();

JDO_EXPORT void jdo_freeInitiateMultipartUploadResult(JdoInitiateMultipartUploadResult_t initiateMultipartUploadResult);

JDO_EXPORT const char* jdo_getInitiateMultipartUploadResultBucket(JdoInitiateMultipartUploadResult_t initiateMultipartUploadResult);

JDO_EXPORT const char* jdo_getInitiateMultipartUploadResultKey(JdoInitiateMultipartUploadResult_t initiateMultipartUploadResult);

JDO_EXPORT const char* jdo_getInitiateMultipartUploadResultUploadId(JdoInitiateMultipartUploadResult_t initiateMultipartUploadResult);

#if defined (__cplusplus)
}
#endif