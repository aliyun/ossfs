#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoObjectPartInfo_t jdo_createObjectPartInfo();

JDO_EXPORT JdoObjectPartInfos_t jdo_createObjectPartInfos();

JDO_EXPORT void jdo_freeObjectPartInfo(JdoObjectPartInfo_t objectPartInfo);

JDO_EXPORT void jdo_freeObjectPartInfos(JdoObjectPartInfos_t objectPartInfos);

JDO_EXPORT int32_t jdo_getObjectPartInfoPartNum(JdoObjectPartInfo_t objectPartInfo);

JDO_EXPORT int64_t jdo_getObjectPartInfoPartSize(JdoObjectPartInfo_t objectPartInfo);

JDO_EXPORT const char* jdo_getObjectPartInfoETag(JdoObjectPartInfo_t objectPartInfo);

JDO_EXPORT void jdo_appendObjectPartInfo(JdoObjectPartInfos_t infos,JdoObjectPartInfo_t objectPartInfo);

// JDO_EXPORT int64_t jdo_getObjectPartInfosSize(JdoObjectPartInfos_t objectPartInfos);

// JDO_EXPORT JdoObjectPartInfo_t jdo_getObjectPartInfoAt(JdoObjectPartInfos_t objectPartInfos, int64_t index);

#if defined (__cplusplus)
}
#endif