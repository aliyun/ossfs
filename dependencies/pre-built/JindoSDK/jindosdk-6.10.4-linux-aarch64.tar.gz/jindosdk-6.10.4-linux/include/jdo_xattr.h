#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoXAttr_t jdo_createXAttr();

JDO_EXPORT void jdo_freeXAttr(JdoXAttr_t xAttr);

JDO_EXPORT void jdo_setXAttrNamespace(JdoXAttr_t xAttr, int ns);

JDO_EXPORT int jdo_getXAttrNamespace(JdoXAttr_t xAttr);

JDO_EXPORT void jdo_setXAttrName(JdoLockInfo_t lockInfo, const char* name);

JDO_EXPORT char* jdo_getXAttrName(JdoLockInfo_t lockInfo);

JDO_EXPORT void jdo_setXAttrValue(JdoLockInfo_t lockInfo, const char* val);

JDO_EXPORT char* jdo_getXAttrValue(JdoLockInfo_t lockInfo);


#if defined (__cplusplus)
}
#endif
