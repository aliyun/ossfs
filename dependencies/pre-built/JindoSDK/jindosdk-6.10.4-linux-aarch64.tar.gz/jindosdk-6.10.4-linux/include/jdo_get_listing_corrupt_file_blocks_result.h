#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoListDirResult_t jdo_createListingCorruptFileBlocksResult();

JDO_EXPORT void jdo_freeListingCorruptFileBlocksResult(JdoGetListingCorruptFileBlocksResult_t corruptFileBlocksResult);

JDO_EXPORT int64_t jdo_getListingCorruptFileBlocksResultSize(JdoGetListingCorruptFileBlocksResult_t corruptFileBlocksResult);

JDO_EXPORT bool jdo_isListingCorruptFileBlocksResultTruncated(JdoGetListingCorruptFileBlocksResult_t corruptFileBlocksResult);

JDO_EXPORT const char* jdo_getListingCorruptFileBlocksResultNextMarker(JdoGetListingCorruptFileBlocksResult_t corruptFileBlocksResult);

JDO_EXPORT JdoFileStatusWithCorruptCheck_t jdo_getListingFileStatusWithCorruptCheck(JdoGetListingCorruptFileBlocksResult_t corruptFileBlocksResult, size_t index);

#if defined (__cplusplus)
}
#endif