#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoConcatSourceList_t jdo_createConcatSourceList();

JDO_EXPORT void jdo_freeConcatSourceList(JdoConcatSourceList_t concatSourceList);

JDO_EXPORT int64_t jdo_getConcatSourceList(JdoConcatSourceList_t concatSourceList);

JDO_EXPORT void jdo_appendConcatSourceList(JdoConcatSourceList_t concatSourceList, JdoConcatSource_t concatSource);

JDO_EXPORT JdoConcatSource_t jdo_getConcatSourceListIterator(JdoConcatSourceList_t concatSourceList, size_t index);


#if defined (__cplusplus)
}
#endif
