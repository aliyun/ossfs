#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoLockInfo_t jdo_createLockInfo();

JDO_EXPORT void jdo_freeLockInfo(JdoLockInfo_t lockInfo);

JDO_EXPORT void jdo_setLockInfoOffset(JdoLockInfo_t lockInfo, int64_t offset);

JDO_EXPORT int64_t jdo_getLockInfoOffset(JdoLockInfo_t lockInfo);

JDO_EXPORT void jdo_setLockInfoLength(JdoLockInfo_t lockInfo, int64_t length);

JDO_EXPORT int64_t jdo_getLockInfoLength(JdoLockInfo_t lockInfo);

JDO_EXPORT void jdo_setLockInfoType(JdoLockInfo_t lockInfo, int16_t lockType);

JDO_EXPORT int16_t jdo_getLockInfoType(JdoLockInfo_t lockInfo);

JDO_EXPORT void jdo_setLockInfoPid(JdoLockInfo_t lockInfo, int64_t pid);

JDO_EXPORT int64_t jdo_getLockInfoPid(JdoLockInfo_t lockInfo);

JDO_EXPORT void jdo_setLockInfoOwner(JdoLockInfo_t lockInfo, uint64_t owner);

JDO_EXPORT uint64_t jdo_getLockInfoOwner(JdoLockInfo_t lockInfo);


#if defined (__cplusplus)
}
#endif
