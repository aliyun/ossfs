#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoCompleteMultipartUploadResult_t jdo_createCompleteMultipartUploadResult();

JDO_EXPORT void jdo_freeCompleteMultipartUploadResult(JdoCompleteMultipartUploadResult_t completeMultipartUploadResult);

JDO_EXPORT const char* jdo_getCompleteMultipartUploadResultBucket(JdoCompleteMultipartUploadResult_t completeMultipartUploadResult);

JDO_EXPORT const char* jdo_getCompleteMultipartUploadResultKey(JdoCompleteMultipartUploadResult_t completeMultipartUploadResult);

JDO_EXPORT const char* jdo_getCompleteMultipartUploadResultETag(JdoCompleteMultipartUploadResult_t completeMultipartUploadResult);

JDO_EXPORT const char* jdo_getCompleteMultipartUploadResultLocation(JdoCompleteMultipartUploadResult_t completeMultipartUploadResult);

JDO_EXPORT const char* jdo_getCompleteMultipartUploadResultChecksumCrc64(JdoCompleteMultipartUploadResult_t completeMultipartUploadResult);

JDO_EXPORT const char* jdo_getCompleteMultipartUploadResultVersionId(JdoCompleteMultipartUploadResult_t completeMultipartUploadResult);

#if defined (__cplusplus)
}
#endif