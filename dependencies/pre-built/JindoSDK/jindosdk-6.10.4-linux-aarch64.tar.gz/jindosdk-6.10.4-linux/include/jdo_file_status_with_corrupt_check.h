#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoFileStatusWithCorruptCheck_t jdo_createFileStatusWithCorruptCheck();

JDO_EXPORT void jdo_freeFileStatusWithCorruptCheck(JdoFileStatusWithCorruptCheck_t fileStatusWithCorruptCheck);

JDO_EXPORT bool jdo_isFileStatusCheckCorrupt(JdoFileStatusWithCorruptCheck_t fileStatusWithCorruptCheck);

JDO_EXPORT JdoFileStatus_t jdo_getCheckedFileStatus(JdoFileStatusWithCorruptCheck_t fileStatusWithCorruptCheck);

#if defined (__cplusplus)
}
#endif