#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT void jdo_freeGetObjectMetaResult(JdoGetObjectMetaResult_t result);

JDO_EXPORT int64_t jdo_getObjectMetaSize(JdoGetObjectMetaResult_t result);

JDO_EXPORT int64_t jdo_getObjectMetaMtime(JdoGetObjectMetaResult_t result);

JDO_EXPORT const char* jdo_getObjectMetaETag(JdoGetObjectMetaResult_t result);

JDO_EXPORT const char* jdo_getObjectMetaVersionId(JdoGetObjectMetaResult_t result);

JDO_EXPORT const char* jdo_getObjectMetaStorageClass(JdoGetObjectMetaResult_t result);

JDO_EXPORT const char* jdo_getObjectMetaChecksumCrc64(JdoGetObjectMetaResult_t result);

#if defined (__cplusplus)
}
#endif
