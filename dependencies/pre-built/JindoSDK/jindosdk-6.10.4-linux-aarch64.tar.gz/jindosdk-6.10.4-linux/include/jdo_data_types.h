#pragma once

#if defined (__cplusplus)
extern "C" {
#endif

typedef void* JdoStringPairMap_t;

typedef void* JdoStoreType_t;
typedef void* JdoFileStatus_t;
typedef void* JdoFileStatusWithCorruptCheck_t;
typedef void* JdoListDirResult_t;
typedef void* JdoContentSummary_t;

typedef void* JdoLockInfo_t;

typedef void* JdoXAttr_t;
typedef void* JdoXAttrList_t;
typedef void* JdoAclEntry_t;
typedef void* JdoAclEntryList_t;
typedef void* JdoAclStatus_t;
typedef void* JdoFileMetaInfo_t;

typedef void* JdoArchiveResult_t;
typedef void* JdoUnarchiveResult_t;
typedef void* JdoRestoreResult_t;

typedef void* JdoConcatSource_t;
typedef void* JdoConcatSourceList_t;
typedef void* JdoFileChecksum_t;
typedef void* JdoServerDefaults_t;

typedef void* JdoSnapshotDiffReport_t;

typedef void* JdoBucketInfo_t;
typedef void* JdoObjectPartInfos_t;
typedef void* JdoInitiateMultipartUploadResult_t;
typedef void* JdoObjectPartInfo_t;
typedef void* JdoCompleteMultipartUploadResult_t;
typedef void* JdoListMultipartUploadsResult_t;

typedef void* JdoGetFinalizeReplyResult_t;
typedef void* JdoGetListingCorruptFileBlocksResult_t;

typedef void* JdoLongs_t;
typedef void* JdoFileBuffers_t;

typedef void* JdoBatchJobTaskList_t;
typedef void* JdoRenameBatchResult_t;
typedef void* JdoRemoveBatchResult_t;
typedef void* JdoGetContentSummaryBatchResult_t;
typedef void* JdoGetFileStatusBatchResult_t;
typedef void* JdoListDirBatchResult_t;
typedef void* JdoBatchJobResult_t;

typedef void* JdoPutObjectResult_t;

typedef void* JdoGetObjectMetaResult_t;
typedef void* JdoListObjectsResult_t;
typedef void* JdoObjectSummary_t;
typedef void* JdoDeleteObjectResult_t;
typedef void* JdoCopyObjectResult_t;

typedef void* JdoGetObjectResult_t;

#if defined (__cplusplus)
}
#endif
