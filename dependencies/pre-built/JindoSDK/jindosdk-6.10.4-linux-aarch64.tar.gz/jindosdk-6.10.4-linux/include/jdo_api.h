#ifndef JINDO_SDK_H_C
#define JINDO_SDK_H_C

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

/* store functions */

JDO_EXPORT JdoStore_t jdo_createStore(JdoOptions_t options, const char* uri);
JDO_EXPORT JdoStore_t jdo_createStoreJava(JdoOptions_t options, const char* uri, void* env);
JDO_EXPORT void jdo_destroyStore(JdoStore_t store);
JDO_EXPORT void jdo_freeStore(JdoStore_t store);

/* capability functions */

JDO_EXPORT bool jdo_hasCapOf(JdoHandleCtx_t ctx, const char* path, int32_t cap);
JDO_EXPORT JdoStoreType_t jdo_getStoreType(JdoHandleCtx_t ctx, const char* path);
JDO_EXPORT char* jdo_resolvePath(JdoHandleCtx_t ctx, const char* path);
JDO_EXPORT void jdo_registerJava(JdoHandleCtx_t ctx, void* jvm);

/* init functions */

JDO_EXPORT void jdo_init(JdoHandleCtx_t ctx, const char* user);
JDO_EXPORT void jdo_init2(JdoHandleCtx_t ctx, JdoLoginUser_t loginUser);

/* context functions */

JDO_EXPORT JdoHandleCtx_t jdo_createHandleCtx1(JdoStore_t store);
JDO_EXPORT JdoHandleCtx_t jdo_createHandleCtx2(JdoStore_t store, JdoIOContext_t io_context);
JDO_EXPORT void jdo_freeHandleCtx(JdoHandleCtx_t ctx);
JDO_EXPORT int32_t jdo_getHandleCtxErrorCode(JdoHandleCtx_t ctx);
JDO_EXPORT const char* jdo_getHandleCtxErrorMsg(JdoHandleCtx_t ctx);

/* async task functions */

JDO_EXPORT void jdo_perform(JdoHandleCtx_t ctx, JdoOperationCall_t call);
JDO_EXPORT void jdo_wait(JdoHandleCtx_t ctx, JdoOperationCall_t call);
JDO_EXPORT void jdo_cancel(JdoHandleCtx_t ctx, JdoOperationCall_t call);
JDO_EXPORT void jdo_freeOperationCall(JdoOperationCall_t call);

/* meta operations */

/* common meta operations */
JDO_EXPORT bool jdo_mkdir(JdoHandleCtx_t ctx, const char* path, bool createParent, int16_t perm, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_mkdirAsync(JdoHandleCtx_t ctx, const char* path, bool createParent, int16_t perm, JdoOptions_t options);
JDO_EXPORT bool jdo_rename(JdoHandleCtx_t ctx, const char* oldpath, const char* newpath, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_renameAsync(JdoHandleCtx_t ctx, const char* oldpath, const char* newpath, JdoOptions_t options);
JDO_EXPORT bool jdo_remove(JdoHandleCtx_t ctx, const char* path, bool recursive, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_removeAsync(JdoHandleCtx_t ctx, const char* path, bool recursive, JdoOptions_t options);
JDO_EXPORT JdoFileStatus_t jdo_getFileStatus(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getFileStatusAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_exists(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_existsAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoListDirResult_t jdo_listDir(JdoHandleCtx_t ctx, const char* path, bool recursive, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_listDirAsync(JdoHandleCtx_t ctx, const char* path, bool recursive, JdoOptions_t options);
/* dfs operations */
JDO_EXPORT JdoContentSummary_t jdo_getContentSummary(JdoHandleCtx_t ctx, const char* path, bool recursive, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getContentSummaryAsync(JdoHandleCtx_t ctx, const char* path, bool recursive, JdoOptions_t options);
JDO_EXPORT bool jdo_setPermission(JdoHandleCtx_t ctx, const char* path, int16_t perm, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setPermissionAsync(JdoHandleCtx_t ctx, const char* path, int16_t perm, JdoOptions_t options);
JDO_EXPORT bool jdo_setOwner(JdoHandleCtx_t ctx, const char* path, const char* user, const char* group, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setOwnerAsync(JdoHandleCtx_t ctx, const char* path, const char* user, const char* group, JdoOptions_t options);
JDO_EXPORT bool jdo_setTimes(JdoHandleCtx_t ctx, const char* path, int64_t mtime, int64_t atime, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setTimesAsync(JdoHandleCtx_t ctx, const char* path, int64_t mtime, int64_t atime, JdoOptions_t options);
JDO_EXPORT bool jdo_truncate(JdoHandleCtx_t ctx, const char* path, int64_t pos, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_truncateAsync(JdoHandleCtx_t ctx, const char* path, int64_t pos, JdoOptions_t options);
JDO_EXPORT bool jdo_concat(JdoHandleCtx_t ctx, const char* path, JdoConcatSourceList_t srcs, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_concatAsync(JdoHandleCtx_t ctx, const char* path, JdoConcatSourceList_t srcs, JdoOptions_t options);
JDO_EXPORT JdoFileChecksum_t jdo_getFileChecksum(JdoHandleCtx_t ctx, const char* path, int8_t type, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getFileChecksumAsync(JdoHandleCtx_t ctx, const char* path, int8_t type, JdoOptions_t options);
/* hdfs operation */
JDO_EXPORT JdoServerDefaults_t jdo_getServerDefaults(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getServerDefaultsAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_recoverLease(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_recoverLeaseAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_isFileClosed(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_isFileClosedAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoGetListingCorruptFileBlocksResult_t jdo_getListingCorruptFileBlocks(JdoHandleCtx_t ctx, const char* path, const char* marker, int maxKeys, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getListingCorruptFileBlocksAsync(JdoHandleCtx_t ctx, const char* path, const char* marker, int maxKeys, JdoOptions_t options);
/* snapshot */
JDO_EXPORT bool jdo_createSnapshot(JdoHandleCtx_t ctx, const char* path, const char* name, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_createSnapshotAsync(JdoHandleCtx_t ctx, const char* path, const char* name, JdoOptions_t options);
JDO_EXPORT bool jdo_deleteSnapshot(JdoHandleCtx_t ctx, const char* path, const char* name, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_deleteSnapshotAsync(JdoHandleCtx_t ctx, const char* path, const char* name, JdoOptions_t options);
JDO_EXPORT bool jdo_renameSnapshot(JdoHandleCtx_t ctx, const char* path, const char* snapshotOldName, const char* snapshotNewName, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_renameSnapshotAsync(JdoHandleCtx_t ctx, const char* snapshotOldName, const char* snapshotNewName, const char* name, JdoOptions_t options);
JDO_EXPORT JdoSnapshotDiffReport_t jdo_snapshotDiff(JdoHandleCtx_t ctx, const char* path, const char* fromSnapshotName, const char* toSnapshotName, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_snapshotDiffAsync(JdoHandleCtx_t ctx, const char* path, const char* fromSnapshotName, const char* toSnapshotName, JdoOptions_t options);
JDO_EXPORT bool jdo_allowSnapshot(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_allowSnapshotAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_disallowSnapshot(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_disallowSnapshotAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
/* acl & xattr */
JDO_EXPORT bool jdo_setXAttr(JdoHandleCtx_t ctx, const char* path, JdoXAttr_t xAttr, int32_t flag, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setXAttrAsync(JdoHandleCtx_t ctx, const char* path, JdoXAttr_t xAttr, int32_t flag, JdoOptions_t options);
JDO_EXPORT bool jdo_removeXAttr(JdoHandleCtx_t ctx, const char* path, JdoXAttr_t xAttr, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_removeXAttrAsync(JdoHandleCtx_t ctx, const char* path, JdoXAttr_t xAttr, JdoOptions_t options);
JDO_EXPORT JdoXAttrList_t jdo_getXAttrs(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getXAttrsAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoXAttrList_t jdo_getXAttrs2(JdoHandleCtx_t ctx, const char* path, JdoXAttrList_t xAttrList, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getXAttrs2Async(JdoHandleCtx_t ctx, const char* path, JdoXAttrList_t xAttrList, JdoOptions_t options);
JDO_EXPORT JdoXAttrList_t jdo_listXAttrs(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_listXAttrsAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_setAcl(JdoHandleCtx_t ctx, const char* path, JdoAclEntryList_t acl, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setAclAsync(JdoHandleCtx_t ctx, const char* path, JdoAclEntryList_t acl, JdoOptions_t options);
JDO_EXPORT bool jdo_modifyAclEntries(JdoHandleCtx_t ctx, const char* path, JdoAclEntryList_t acls, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_modifyAclEntriesAsync(JdoHandleCtx_t ctx, const char* path, JdoAclEntryList_t acls, JdoOptions_t options);
JDO_EXPORT bool jdo_removeAclEntries(JdoHandleCtx_t ctx, const char* path, JdoAclEntryList_t acls, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_removeAclEntriesAsync(JdoHandleCtx_t ctx, const char* path, JdoAclEntryList_t acls, JdoOptions_t options);
JDO_EXPORT bool jdo_removeAcl(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_removeAclAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_removeDefaultAcl(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_removeDefaultAclAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoAclStatus_t jdo_getAclStatus(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getAclStatusAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_setMeta(JdoHandleCtx_t ctx, const char* path, JdoFileMetaInfo_t metaInfo, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setMetaAsync(JdoHandleCtx_t ctx, const char* path, JdoFileMetaInfo_t metaInfo, JdoOptions_t options);
/* symlink operations */
JDO_EXPORT bool jdo_createSymlink(JdoHandleCtx_t ctx, const char* target, const char* link, bool createParent, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_createSymlinkAsync(JdoHandleCtx_t ctx, const char* target, const char* link, bool createParent, JdoOptions_t options);
JDO_EXPORT char* jdo_getLinkTarget(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getLinkTargetAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoFileStatus_t jdo_getFileLinkStatus(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getFileLinkStatusAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
/* posix */
JDO_EXPORT bool jdo_mknod(JdoHandleCtx_t ctx, const char* path, int16_t perm, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_mknodAsync(JdoHandleCtx_t ctx, const char* path, int16_t perm, JdoOptions_t options);
JDO_EXPORT bool jdo_fallocate(JdoHandleCtx_t ctx, const char* path, int64_t offset, int64_t length, int32_t flag, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_fallocateAsync(JdoHandleCtx_t ctx, const char* path, int64_t offset, int64_t length, int32_t flag, JdoOptions_t options);
JDO_EXPORT bool jdo_setLock(JdoHandleCtx_t ctx, const char* path, JdoLockInfo_t lockInfo, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setLockAsync(JdoHandleCtx_t ctx, const char* path, JdoLockInfo_t lockInfo, JdoOptions_t options);
JDO_EXPORT JdoLockInfo_t jdo_getLock(JdoHandleCtx_t ctx, const char* path, JdoLockInfo_t lockInfo, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getLockAsync(JdoHandleCtx_t ctx, const char* path, JdoLockInfo_t lockInfo, JdoOptions_t options);
/* storageClass */
JDO_EXPORT JdoArchiveResult_t jdo_archive(JdoHandleCtx_t ctx, const char* path, int8_t storageClass, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_archiveAsync(JdoHandleCtx_t ctx, const char* path, int8_t storageClass, JdoOptions_t options);
JDO_EXPORT JdoUnarchiveResult_t jdo_unarchive(JdoHandleCtx_t ctx, const char* path, int8_t storageClass, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_unarchiveAsync(JdoHandleCtx_t ctx, const char* path, int8_t storageClass, JdoOptions_t options);
JDO_EXPORT JdoRestoreResult_t jdo_restore(JdoHandleCtx_t ctx, const char* path, int32_t days, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_restoreAsync(JdoHandleCtx_t ctx, const char* path, int32_t days, JdoOptions_t options);
JDO_EXPORT bool jdo_setStoragePolicy(JdoHandleCtx_t ctx, const char* path, int8_t storagePolicyId, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_setStoragePolicyAsync(JdoHandleCtx_t ctx, const char* path, int8_t storagePolicyId, JdoOptions_t options);
JDO_EXPORT bool jdo_unsetStoragePolicy(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_unsetStoragePolicyAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT int8_t jdo_getStoragePolicy(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getStoragePolicyAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT char* jdo_checkStoragePolicy(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_checkStoragePolicyAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT int8_t jdo_getLocalStoragePolicy(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getLocalStoragePolicyAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
/* auth */
JDO_EXPORT JdoAuthCredentialsProviderOptions_t jdo_checkPermission(JdoHandleCtx_t ctx, const char* path, int actionType, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_checkPermissionAsync(JdoHandleCtx_t ctx, const char* path, int actionType, JdoOptions_t options);
/* batch job */
JDO_EXPORT JdoRenameBatchResult_t jdo_renameBatch(JdoHandleCtx_t ctx, JdoBatchJobTaskList_t taskList, JdoOptions_t options);
JDO_EXPORT JdoRemoveBatchResult_t jdo_removeBatch(JdoHandleCtx_t ctx, JdoBatchJobTaskList_t taskList, JdoOptions_t options);
JDO_EXPORT JdoGetContentSummaryBatchResult_t jdo_getContentSummaryBatch(JdoHandleCtx_t ctx, JdoBatchJobTaskList_t taskList, JdoOptions_t options);
JDO_EXPORT JdoGetFileStatusBatchResult_t jdo_getFileStatusBatch(JdoHandleCtx_t ctx, JdoBatchJobTaskList_t taskList, JdoOptions_t options);
JDO_EXPORT JdoListDirBatchResult_t jdo_listDirBatch(JdoHandleCtx_t ctx, JdoBatchJobTaskList_t taskList, JdoOptions_t options);
JDO_EXPORT JdoBatchJobResult_t jdo_getBatchJobResult(JdoHandleCtx_t ctx, const char* path, const char* jobType, const char* jobId, const char* continuationToken, JdoBatchJobTaskList_t taskList, JdoOptions_t options);

/* i/o operations */

/**
 * jdo_open - open a file. jdo_freeIOContext should be called to deallocate JdoIOContext_t.
 * @param path The path to the file, the string should ends with 0.
 * @param flags Use the flags as follows:
                JDO_OPEN_FLAG_CREATE - to create a file if it does not exist, else return JDO_FILE_ALREADY_EXISTS_ERROR.
                JDO_OPEN_FLAG_APPEND - to append to a file if it exists, else return JDO_FILE_NOT_FOUND_ERROR.
                JDO_OPEN_FLAG_OVERWRITE - to truncate a file if it exists, else return JDO_FILE_NOT_FOUND_ERROR.
                JDO_OPEN_FLAG_CREATE|JDO_OPEN_FLAG_APPEND - to create a file if it does not exist, else append to an existing file.
                JDO_OPEN_FLAG_CREATE|JDO_OPEN_FLAG_OVERWRITE - to create a file if it does not exist, else overwrite an existing file.
                JDO_OPEN_FLAG_SYNC_BLOCK - to force closed blocks to the disk device. In addition Syncable.hsync() should be called after each write, if true synchronous behavior is required.
                JDO_OPEN_FLAG_LAZY_PERSIST - Create the block on transient storage (RAM) if available.
                JDO_OPEN_FLAG_NEW_BLOCK - Append data to a new block instead of end of the last partial block.
                JDO_OPEN_FLAG_NO_LOCAL_WRITE - Advise that a block replica NOT be written to the local DataNode where 'local' means the same host as the client is being run on.
                JDO_OPEN_FLAG_RANDOM_WRITE - to random write to a file if it does not exist, else return JDO_FILE_NOT_FOUND_ERROR.
                JDO_OPEN_FLAG_CREATE|JDO_OPEN_FLAG_RANDOM_WRITE - to create a file if it does not exist, else random write to an existing file.
                JDO_OPEN_FLAG_OVERWRITE|JDO_OPEN_FLAG_RANDOM_WRITE - to truncate a file and random write to the file if it exists, else return JDO_FILE_NOT_FOUND_ERROR.
                JDO_OPEN_FLAG_CREATE|JDO_OPEN_FLAG_OVERWRITE|JDO_OPEN_FLAG_RANDOM_WRITE - to truncate a file if it exists, else create a file, and then random write to the file .
                READ_ONLY - to read a file if it exists, else return JDO_FILE_NOT_FOUND_ERROR.
                Following combinations are not valid:
                JDO_OPEN_FLAG_APPEND|JDO_OPEN_FLAG_OVERWRITE
                CREATE|APPEND|OVERWRITE
 * @param perm The permission of the file.
 * @return Returns the JdoIOContext_t to the open file or NULL on error.
 */
JDO_EXPORT JdoIOContext_t jdo_open(JdoHandleCtx_t ctx2, const char* path, int32_t flags, int16_t perm, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_openAsync(JdoHandleCtx_t ctx2, const char* path, int32_t flags, int16_t perm, JdoOptions_t options);
JDO_EXPORT bool jdo_close(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_closeAsync(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT JdoGetFinalizeReplyResult_t jdo_getFinalizeReply(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT void jdo_freeIOContext(JdoIOContext_t io_context);
JDO_EXPORT int64_t jdo_read(JdoHandleCtx_t ctx2, char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_readAsync(JdoHandleCtx_t ctx2, char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT int64_t jdo_readFully(JdoHandleCtx_t ctx2, char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_readFullyAsync(JdoHandleCtx_t ctx2, char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT int64_t jdo_pread(JdoHandleCtx_t ctx2, char* buffer, int64_t length, int64_t offset, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_preadAsync(JdoHandleCtx_t ctx2, char* buffer, int64_t length, int64_t offset, JdoOptions_t options);
JDO_EXPORT int64_t jdo_preadv(JdoHandleCtx_t ctx2, JdoFileBuffers_t buffers, JdoLongs_t lengths, JdoLongs_t offsets, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_preadvAsync(JdoHandleCtx_t ctx2, JdoFileBuffers_t buffers, JdoLongs_t lengths, JdoLongs_t offsets, JdoOptions_t options);
JDO_EXPORT int64_t jdo_write(JdoHandleCtx_t ctx2, const char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_writeAsync(JdoHandleCtx_t ctx2, const char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT bool jdo_flush(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_flushAsync(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT int64_t jdo_seek(JdoHandleCtx_t ctx2, int64_t offset, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_seekAsync(JdoHandleCtx_t ctx2, int64_t offset, JdoOptions_t options);
JDO_EXPORT int64_t jdo_tell(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_tellAsync(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT int64_t jdo_getFileLength(JdoHandleCtx_t ctx2, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getFileLengthAsync(JdoHandleCtx_t ctx2, JdoOptions_t options);

/* tool */
JDO_EXPORT void jdo_free(void *ptr);

/* object operations */
/* bucket operations */
JDO_EXPORT JdoBucketInfo_t jdo_getBucketInfo(JdoHandleCtx_t ctx0, const char* path, JdoOptions_t options);
/* normal object operations */
JDO_EXPORT int64_t jdo_putObject(JdoHandleCtx_t ctx, const char* path, const char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_putObjectAsync(JdoHandleCtx_t ctx, const char* path, const char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT int64_t jdo_getObject(JdoHandleCtx_t ctx, const char* path, char* buffer, int64_t length, int64_t offset, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getObjectAsync(JdoHandleCtx_t ctx, const char* path, char* buffer, int64_t length, int64_t offset, JdoOptions_t options);
JDO_EXPORT JdoGetObjectResult_t jdo_getObjectWithMeta(JdoHandleCtx_t ctx, const char* path, char* buffer, int64_t length, int64_t offset, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getObjectAsyncWithMeta(JdoHandleCtx_t ctx, const char* path, char* buffer, int64_t length, int64_t offset, JdoOptions_t options);
JDO_EXPORT JdoGetObjectMetaResult_t jdo_getObjectMeta(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_getObjectMetaAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoListObjectsResult_t jdo_listObjects(JdoHandleCtx_t ctx, const char* path, const char* delimiter, const char* marker, int maxKeys, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_listObjectsAsync(JdoHandleCtx_t ctx, const char* path, const char* delimiter, const char* marker, int maxKeys, JdoOptions_t options);
JDO_EXPORT JdoDeleteObjectResult_t jdo_deleteObject(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_deleteObjectAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoCopyObjectResult_t jdo_copyObject(JdoHandleCtx_t ctx, const char* srcPath, const char* dstPath, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_copyObjectAsync(JdoHandleCtx_t ctx, const char* srcPath, const char* dstPath, JdoOptions_t options);
/* mpu object operations */
JDO_EXPORT JdoInitiateMultipartUploadResult_t jdo_initMultipartUpload(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_initMultipartUploadAsync(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT JdoObjectPartInfo_t jdo_uploadPart(JdoHandleCtx_t ctx, const char* path, const char* uploadId, int64_t partNum, const char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_uploadPartAsync(JdoHandleCtx_t ctx, const char* path, const char* uploadId, int64_t partNum, const char* buffer, int64_t length, JdoOptions_t options);
JDO_EXPORT JdoObjectPartInfo_t jdo_uploadPartCopy(JdoHandleCtx_t ctx, const char* srcPath, const char* dstPath, const char* uploadId, int64_t partNum, int64_t start, int64_t end, JdoOptions_t options);
JDO_EXPORT JdoCompleteMultipartUploadResult_t jdo_completeMultipartUpload(JdoHandleCtx_t ctx, const char* path, const char* uploadId, JdoObjectPartInfos_t partInfoList, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_completeMultipartUploadAsync(JdoHandleCtx_t ctx, const char* path, const char* uploadId, JdoObjectPartInfos_t partInfoList, JdoOptions_t options);
JDO_EXPORT JdoListMultipartUploadsResult_t jdo_listMultipartUpload(JdoHandleCtx_t ctx, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_abortMultipartUpload(JdoHandleCtx_t ctx, const char* path, char* uploadId, JdoOptions_t options);
JDO_EXPORT JdoOperationCall_t jdo_abortMultipartUploadAsync(JdoHandleCtx_t ctx, const char* path, char* uploadId, JdoOptions_t options);
/* tagging object operations */
JDO_EXPORT bool jdo_putObjectTagging(JdoHandleCtx_t ctx0, const char* path, JdoStringPairMap_t tags, JdoOptions_t options);
JDO_EXPORT JdoStringPairMap_t jdo_getObjectTagging(JdoHandleCtx_t ctx0, const char* path, JdoOptions_t options);
JDO_EXPORT bool jdo_putTagging(JdoHandleCtx_t ctx0, const char* path, JdoStringPairMap_t tags, JdoOptions_t options);

/* get metrics */
JDO_EXPORT char* jdo_dumpMetrics(JdoHandleCtx_t ctx0, int8_t dumper_type, int8_t result_type, JdoOptions_t options0);

#if defined (__cplusplus)
}
#endif

#endif
