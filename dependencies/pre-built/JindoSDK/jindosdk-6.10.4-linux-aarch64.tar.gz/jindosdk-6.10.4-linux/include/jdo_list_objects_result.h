#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT void jdo_freeListObjectsResult(JdoListObjectsResult_t result);

JDO_EXPORT bool jdo_getListObjectsTruncated(JdoListObjectsResult_t result);

JDO_EXPORT int32_t jdo_getListObjectsMaxKeys(JdoListObjectsResult_t result);

JDO_EXPORT int32_t jdo_getListObjectsKeyCount(JdoListObjectsResult_t result);

JDO_EXPORT const char* jdo_getListObjectsNextMarker(JdoListObjectsResult_t result);

JDO_EXPORT uint64_t jdo_getListObjectsCommonPrefixSize(JdoListObjectsResult_t result);

JDO_EXPORT const char* jdo_getListObjectsCommonPrefix(JdoListObjectsResult_t result, size_t index);

JDO_EXPORT uint64_t jdo_getListObjectsObjectListSize(JdoListObjectsResult_t result);

JDO_EXPORT JdoObjectSummary_t jdo_getListObjectsObjectList(JdoListObjectsResult_t result, size_t index);

#if defined (__cplusplus)
}
#endif
