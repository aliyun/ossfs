#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoLongs_t jdo_createLongs();

JDO_EXPORT void jdo_freeLongs(JdoLongs_t longs);

JDO_EXPORT int64_t jdo_getLongsSize(JdoLongs_t longs);

JDO_EXPORT void jdo_appendLong(JdoLongs_t longs, int64_t val);

JDO_EXPORT int64_t jdo_getLongsIterator(JdoLongs_t longs, size_t index);

#if defined (__cplusplus)
}
#endif
