#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoFileMetaInfo_t jdo_createFileMetaInfo();

JDO_EXPORT void jdo_freeFileMetaInfo(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoOwner(JdoFileMetaInfo_t fileMetaInfo, const char* owner);

JDO_EXPORT char* jdo_getFileMetaInfoOwner(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoGroup(JdoFileMetaInfo_t fileMetaInfo, const char* group);

JDO_EXPORT char* jdo_getFileMetaInfoGroup(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoPermission(JdoFileMetaInfo_t fileMetaInfo, int perm);

JDO_EXPORT int16_t jdo_getFileMetaInfoPermission(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoXAttrList(JdoFileMetaInfo_t fileMetaInfo, JdoXAttrList_t xAttrList);

JDO_EXPORT JdoXAttrList_t jdo_getFileMetaInfoXAttrList(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoAclSpec(JdoFileMetaInfo_t fileMetaInfo, const char* aclSpec);

JDO_EXPORT char* jdo_getFileMetaInfoAclSpec(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoMtime(JdoFileMetaInfo_t fileMetaInfo, int64_t mtime);

JDO_EXPORT int64_t jdo_getFileMetaInfoMtime(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoAtime(JdoFileMetaInfo_t fileMetaInfo, int64_t atime);

JDO_EXPORT int64_t jdo_getFileMetaInfoAtime(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoReplication(JdoFileMetaInfo_t fileMetaInfo, short replication);

JDO_EXPORT short jdo_getFileMetaInfoReplication(JdoFileMetaInfo_t fileMetaInfo);

JDO_EXPORT void jdo_setFileMetaInfoBlockSize(JdoFileMetaInfo_t fileMetaInfo, int64_t blockSize);

JDO_EXPORT int64_t jdo_getFileMetaInfoBlockSize(JdoFileMetaInfo_t fileMetaInfo);


#if defined (__cplusplus)
}
#endif
