#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoConcatSource_t jdo_createConcatSource();

JDO_EXPORT void jdo_freeConcatSource(JdoConcatSource_t source);

JDO_EXPORT void jdo_setConcatSourcePath(JdoConcatSource_t source, const char* path);

JDO_EXPORT char* jdo_getConcatSourcePath(JdoConcatSource_t source);


#if defined (__cplusplus)
}
#endif
