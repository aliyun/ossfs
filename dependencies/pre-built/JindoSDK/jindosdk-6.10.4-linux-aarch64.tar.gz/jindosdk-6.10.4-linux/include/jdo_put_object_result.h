#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoPutObjectResult_t jdo_createPutObjectResult();

JDO_EXPORT void jdo_freePutObjectResult(JdoPutObjectResult_t putObjectResult);

JDO_EXPORT const char* jdo_getPutObjectResultETag(JdoPutObjectResult_t putObjectResult);

JDO_EXPORT const char* jdo_getPutObjectResultVersionId(JdoPutObjectResult_t putObjectResult);

JDO_EXPORT const char* jdo_getPutObjectResultChecksumCrc64(JdoPutObjectResult_t putObjectResult);

#if defined (__cplusplus)
}
#endif
