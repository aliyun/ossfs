#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoAclStatus_t jdo_createAclStatus();

JDO_EXPORT void jdo_freeAclStatus(JdoAclStatus_t aclStatus);

JDO_EXPORT void jdo_setAclStatusOwner(JdoAclStatus_t aclStatus, const char* owner);

JDO_EXPORT char* jdo_getAclStatusOwner(JdoAclStatus_t JdoAclStatus_t);

JDO_EXPORT void jdo_setAclStatusGroup(JdoAclStatus_t aclStatus, const char* group);

JDO_EXPORT char* jdo_getAclStatusGroup(JdoAclStatus_t JdoAclStatus_t);

JDO_EXPORT void jdo_setAclStatusAclEntries(JdoAclStatus_t aclStatus, JdoAclEntryList_t aclEntries);

JDO_EXPORT JdoAclEntry_t jdo_getAclStatusAclEntry(JdoAclStatus_t JdoAclStatus_t, size_t index);

JDO_EXPORT void jdo_setAclStatusPermission(JdoAclStatus_t aclStatus, int perm);

JDO_EXPORT int jdo_getAclStatusPermission(JdoAclStatus_t JdoAclStatus_t);

JDO_EXPORT void jdo_setAclStatusStickyBit(JdoAclStatus_t aclStatus, bool stickyBit);

JDO_EXPORT bool jdo_isAclStatusStickyBit(JdoAclStatus_t JdoAclStatus_t);

#if defined (__cplusplus)
}
#endif
