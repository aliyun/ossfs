#pragma once

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <errno.h>

#include "jdo_common.h"
#include "jdo_data_types.h"

#if defined (__cplusplus)
extern "C" {
#endif

JDO_EXPORT JdoGetFinalizeReplyResult_t jdo_createFinalizeReplyResult();

JDO_EXPORT void jdo_freeFinalizeReplyResult(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT const char* jdo_getFinalizeReplyResultUri(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT const char* jdo_getFinalizeReplyResultUploadId(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT const char* jdo_getFinalizeReplyResultBucket(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT const char* jdo_getFinalizeReplyResultDestinationKey(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT int64_t jdo_getFinalizeReplyResultCreated(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT int64_t jdo_getFinalizeReplyResultSaved(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT const char* jdo_getFinalizeReplyResultDate(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT const char* jdo_getFinalizeReplyResultClientCrc(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT int64_t jdo_getFinalizeReplyResultPartSize(JdoGetFinalizeReplyResult_t replyResult);

JDO_EXPORT const char* jdo_getFinalizeReplyResultPart(JdoGetFinalizeReplyResult_t replyResult, int64_t index);

#if defined (__cplusplus)
}
#endif
